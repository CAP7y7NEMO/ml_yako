<?php
  session_start();
  // include_once("seguranca.php");
  // seguranca_adm();
  // include_once("conexao.php");
require_once('view_coderphp/funcoes.php');
require_once('view_coderphp/header.php');
carrega_pagina();
require_once('view_coderphp/footer.php');

// require_once('config/config.php');

// include "pixelfacebook.php";

 ?>

