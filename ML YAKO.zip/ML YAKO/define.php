<?php 

define("INCLUDE_PATH", "https://merpago.site/ML2024CODER/");

?>