<?php
global $pdo;
try {
	$pdo = new PDO("mysql:dbname=iml;host=localhost", "root", "");

} catch (PDOException $e) {

	echo "FALHOU" . $e->getMessage();
	exit;

}
?>
