<?php
define('INCLUDE_PATH','http://localhost/projeto_ismafer/coderphp/');
?>

