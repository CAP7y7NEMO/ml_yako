<?php
include __DIR__.'/../../config/config.php';
global $pdo;

if(isset($_POST['codigo'])):

$codigo = addslashes(htmlspecialchars_decode($_POST['codigo']));
$statusboleto = 1;

 $sql=$pdo->prepare("INSERT INTO coderphp_boleto set nomeproduto=:nomeproduto");

  $sql->bindValue(":nomeproduto", $codigo);
 $sql->execute()

?>
<script type="text/javascript">
  let timerInterval
  Swal.fire({
    title: 'Cadastrado com sucesso.',

    timer: 2000,
    timerProgressBar: true,
    didOpen: () => {
      Swal.showLoading()
      const b = Swal.getHtmlContainer().querySelector('b')
      timerInterval = setInterval(() => {
        b.textContent = Swal.getTimerLeft()
      }, 100)
    },
    willClose: () => {
      clearInterval(timerInterval)
    }
  }).then((result) => {
      /* Read more about handling dismissals below */
    if (result.dismiss === Swal.DismissReason.timer) {
      console.log('I was closed by the timer')
    }
  })
</script>
<?php
endif; 

?>


<div class="content p-1 grande" >
  <div class="list-group-item ">
 

    <div class="container-fluid">


      <h4> PIXEL DO META  </h4>
      <br>

      <div id="accordion">
        <div class="card">
          <div class="card-header" id="headingOne">
            <h5 class="mb-0">
              <button class="btn btn-link" data-toggle="collapse" data-target="#collapseOne" aria-expanded="true" aria-controls="collapseOne">
              PIXEL DO FACEBOOK
              </button>
            </h5>
          </div>

          <div id="collapseOne" class="collapse show" aria-labelledby="headingOne" data-parent="#accordion">
            <div class="card-body">
             <div class="row">

              <div class="col-md-4">
                <form method="post">
                 <div class="col">
                  <input type="text" class="form-control" required name="codigo" placeholder="id do pixel">
                </div>

                <?= @$novo; ?>
                <br>
                


         
                <input style="margin-left:28px;" type="submit" value="CADASTRAR" class="btn btn-outline-success">
              </div>







            </form>

          </div>
<br><br>
          <?php 
global $pdo;
$array =[];
$sql=$pdo->prepare("SELECT * FROM coderphp_boleto order by id desc");
$sql->execute();
if($sql->rowCount() > 0){
  $array = $sql->fetchAll();
}

?>




<table class="table">
  <thead>
    <tr>
      <th scope="col">ID</th>
      <th scope="col">ID PIXEL META</th>
      
     
      <th scope="col">DEL</th>
    </tr>
  </thead>
  <tbody>
    <?php

       foreach($array as $coderphp):

    ?> 
    
    <tr>
      <th scope="row"><?= $coderphp['id'] ?></th>
      <td><?= $coderphp['nomeproduto'] ?></td>
 
     
      <td><a href="&id=<?=  $coderphp['id'] ?>" style="color:rgb(234, 62, 53);text-decoration: none;font-size:18px;" href="#"><i class="fa-solid fa-trash"></i> </a></td>
    </tr>


<?php 

endforeach; ?>


  </tbody>
</table>
        </div>
      </div>
    </div>




    
  </div>
</div>







</div>



</div>

</div>






</div>
</div>











</div>



</div>


</div>
</div>

</div>