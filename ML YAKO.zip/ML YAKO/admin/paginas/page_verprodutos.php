<?php
include "../config/config.php";
global $pdo;

$ok=[];
$sql=$pdo->prepare("SELECT * FROM coderphp_produtos ORDER BY ID DESC");
$sql->execute();

if($sql->rowCount() > 0){
  $ok = $sql->fetchAll();
}




?>

<div class="content " >

  <h4 style="margin-top:10px !important;color:white;text-align: center;">Produtos listado</h4>

<table class="table table-dark">
  <thead>
<tr>
      <th scope="row">#Id</th>
      <td>Nome produto</td>
      <td>Preço original</td>
      
     
     
      <td>Capa</td>
        
      <td>Ações</td>
      
     
      
    
     
    </tr>

    
  </thead>
<tbody>


      <?php 
      foreach($ok as $cc):
        ?>
        <tr>
          <th scope="col"><?= $cc['id'] ?></th>
          
          
          <th scope="col"><?= $cc['title'] ?></th>
         


       
          <th scope="col"><?= $cc['preco'] ?></th>
                   
          <th scope="col"><img border="0" height="60px" src="<?= $cc['fotos1'] ?>" alt=""></th>
          
          
          <th scope="col"><a title="editar" alt="editar" style="cursor:pointer;color:rgb(18, 229, 130);" onclick="window.location.href='editarprodutos?id=<?= $cc['id'] ?>'"><i class="fa-solid fa-pen-to-square"></i></a> <a title="deletar" alt="deletar" style="cursor:pointer;color:red;" onclick="window.location.href='deletarprodutos?id=<?= $cc['id'] ?>'"><i class="fa-solid fa-trash"></i></a> </th>
          
          
          
         


        </tr>

      <?php endforeach; ?>

    </tbody>
</table>




</div>







</form>
</div>
</div>
</div>
</div>


<script type="text/javascript">
  $(function () {
    $('[data-toggle="tooltip"]').tooltip()
  })
</script>


</div>
</div>
</div>
</div>

</div>






</div>
</div>











</div>



</div>


</div>
</div>

</div>