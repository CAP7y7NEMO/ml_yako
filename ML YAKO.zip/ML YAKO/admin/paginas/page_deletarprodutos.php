<?php

include "../config/config.php";
if(isset($_GET['id']) && !empty($_SESSION['usuarioId'])):
$id = $_GET['id'];

global $pdo;
$sql=$pdo->prepare("delete from coderphp_produtos  WHERE id = '$id'");
$sql->execute();
endif;


?>

<script type="text/javascript">
	window.location.href='verprodutos';
</script>