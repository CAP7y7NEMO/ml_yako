<?php

$host = "localhost";
$user = "root";
$senha = "";
$bancodedados = "iml";
$conexao = mysqli_connect($host, $user, $senha, $bancodedados);
?>
