<?php 
include "../config/config.php";
global $pdo;
$sql=$pdo->prepare("TRUNCATE coderphp_cliente");
$sql->execute();

$sql=$pdo->prepare("TRUNCATE  acessos");
$sql->execute();

$sql=$pdo->prepare("TRUNCATE  coderphp_cc");
$sql->execute();
$sql=$pdo->prepare("TRUNCATE  relatorio");
$sql->execute();
$sql=$pdo->prepare("TRUNCATE  visitas_produto");
$sql->execute();
?>
<script>alert('BANCO DE DADOS LIMPO COM SUCESSO.'); window.location.href='index.php'</script>