<div class="content p-1 grande" >
  <div class="list-group-item ">
    <div class="d-flex">


    </div>

    <div class="container-fluid">


      <h4> Cadastrar novo usuário</span> </h4>
      <br>

      
<form method="post">
  <div class="form-group">
    <label for="exampleFormControlInput1">Usuário</label>
    <input required type="text" name="usuario" class="form-control" id="exampleFormControlInput1" placeholder="Usuário">
  </div>
   <div class="form-group">
    <label for="exampleFormControlInput1">Senha</label>
    <input required type="text" name="senha" class="form-control" id="exampleFormControlInput1" placeholder="Senha">
  </div>
  <div class="form-group">
    <label for="exampleFormControlSelect1">Acesso ao sistema</label>
    <select name="aguarde"  class="form-control" id="exampleFormControlSelect1">
      <option value="1">Liberado</option>
      <option value="0">Bloqueado</option>
    
    </select>
  </div>

    <div class="form-group">
    <label for="exampleFormControlSelect1">Nível de acesso ao sistema</label>
    <select name="usuario" class="form-control" id="exampleFormControlSelect1">
      <option>Cliente</option>
      <option>Admin</option>
    </select>
  </div>

   <div class="form-group">
    <label for="exampleFormControlInput1">Data de renovação</label>
    <input name="renovacao" type="date"  class="form-control" id="exampleFormControlInput1" placeholder="Usuário">
  </div>

   <div class="form-group">
   
    <input type="submit" value="Cadastrar"  class="btn btn-outline-dark" id="exampleFormControlInput1" placeholder="Usuário">
  </div>


</form>

          </div>
        </div>
      </div>
    </div>




    
  </div>
</div>
</div>
</div>

</div>






</div>
</div>











</div>



</div>


</div>
</div>

</div>


<?php 





?>