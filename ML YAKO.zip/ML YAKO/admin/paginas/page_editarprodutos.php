<?php
include "../config/config.php";
global $pdo;

if(isset($_GET['id']) && !empty($_GET['id'])):
$id = addslashes(htmlspecialchars_decode($_GET['id']));

else:
  ?>
 <script>window.location.href="verprodutos"</script>

  <?php
endif;

$ok=[];
$sql=$pdo->prepare("SELECT * FROM coderphp_produtos WHERE id=:id");
$sql->bindValue(":id", $id);
$sql->execute();

if($sql->rowCount() > 0){
  $ok = $sql->fetchAll();
}



foreach ($ok as $cc):

endforeach;


?>


<div class="content p-1 grande" >
  <div class="list-group-item ">
    <div class="d-flex">


    </div>

    <div class="container-fluid">


      <h4> Cadastrar novo produto</span> </h4>
      <br>

      
<form method="post" enctype="multipart/form-data">

  <div class="form-group">
    <label for="exampleFormControlInput1">Título do produto</label>
    <input required type="text" value="<?= $cc['title'] ?>" name="titulo" class="form-control" id="exampleFormControlInput1" placeholder="Título do produto">
  </div>
   <div class="form-group">
    <label for="exampleFormControlInput1">Preço original</label>
    <input required type="text" value="<?= $cc['preco'] ?>" name="preco" class="form-control" id="exampleFormControlInput1" placeholder="Preço original">
  </div>

 
  

  


   <div class="form-group">
   
    <input type="submit" value="Atualizar"  class="btn btn-outline-dark" id="exampleFormControlInput1" placeholder="Usuário">
  </div>


</form>

          </div>
        </div>
      </div>
    </div>




    
  </div>
</div>
</div>
</div>

</div>






</div>
</div>











</div>



</div>


</div>
</div>
<script src="https://unpkg.com/sweetalert/dist/sweetalert.min.js"></script>
</div>

<?php 
if(isset($_POST['titulo'])):
  $titulo = addslashes(htmlspecialchars_decode($_POST['titulo']));
  $preco = addslashes(htmlspecialchars_decode($_POST['preco']));
 
 


  global $pdo;

    $sql=$pdo->prepare("UPDATE  coderphp_produtos set title=:title, preco=:preco WHERE id =:id ");
    $sql->bindValue(":title", $titulo);
    $sql->bindValue(":preco", $preco);
 
    $sql->bindValue(":id", $id);
   
    $sql->execute();


sleep(1);
?>
<script>swal({
      title: "Atualizado com sucesso.",

      icon: "success",
      
  });</script>
<?php

    endif;
  ?>