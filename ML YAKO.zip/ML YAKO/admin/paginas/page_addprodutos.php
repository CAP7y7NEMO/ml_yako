<?php 
include "../config/config.php";
 global $pdo;





?>



    
  </div>
</div>
</div>
</div>

</div>


<script src="https://ajax.googleapis.com/ajax/libs/jquery/2.1.1/jquery.min.js"></script>

<script>  $(document).ready(function () {
    $('input[type=radio]').change(function() {
        $('input[type=radio]:checked').not(this).prop('checked', false);
    });
});</script>

</div>
</div>











</div>



</div>


</div>
</div>
<script src="https://unpkg.com/sweetalert/dist/sweetalert.min.js"></script>
</div>

<?php 

// json file name
            $filename = "coderphp.json";
            
            // Read the JSON file in PHP
            $data = file_get_contents($filename);

// Convert the JSON String into PHP Array
            $array = json_decode($data, true);

foreach($array as $coderphp):


// O link a ser verificado
$url = $coderphp['link'];

// Expressão regular para encontrar um padrão que começa com "ML" seguido de letras e números
$pattern = '/ML[A-Z0-9]+/';

// Usar preg_match_all para capturar todas as ocorrências que começam com "ML"
if (preg_match_all($pattern, $url, $matches)) {
    // Verificar se há pelo menos duas correspondências
    if (isset($matches[0][1])) {
        // Pegar a segunda correspondência (índice 1)
        $secondMatch = $matches[0][1];
        echo "Segunda correspondência encontrada: " . $secondMatch;
    } else {
        echo "Não foi encontrada uma segunda correspondência.";
    }
} else {
    echo "Nenhuma correspondência encontrada no formato desejado.";
}



    

   foreach ($coderphp['list1'] as $chave => $valor) {
    $dados['fotos' . ($chave + 1)] = $valor['src'];


 }


  $sql=$pdo->prepare("INSERT INTO  coderphp_produtos set title=:title, preco=:preco, descricao=:descricao,  fotos1=:fotos1,fotos2=:fotos2,fotos3=:fotos3,fotos4=:fotos4,fotos5=:fotos5 ,categoria=:categoria, avalicao=:avalicao ");
  
    $sql->bindValue(":title", $coderphp['title']);
    $sql->bindValue(":preco", $coderphp['price']);
    $sql->bindValue(":descricao", $coderphp['descri']);
     $sql->bindValue(":fotos1", $dados['fotos1']);
 $sql->bindValue(":fotos2", $dados['fotos2']);
 $sql->bindValue(":fotos3", $dados['fotos3']);
 $sql->bindValue(":fotos4", $dados['fotos4']);
 $sql->bindValue(":fotos5", $dados['fotos5']);
    $sql->bindValue(":categoria", $coderphp['breadcrumb__link']);
    $sql->bindValue(":avalicao", $secondMatch);

    $sql->execute();


 endforeach; 




if(isset($coderphp['title'])):
  
?>

<script>swal({
      title: "Cadastro realizado com sucesso.",

      icon: "success",
      
  });</script>

<?php
endif;


