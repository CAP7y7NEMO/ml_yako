<?php
include "../config/config.php";

?>
<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <title>Dashboard  | <?= $_SESSION['usuarioUSer']; ?></title>

    <link rel="stylesheet" href="css/bootstrap.min.css">
<script src="//cdn.jsdelivr.net/npm/sweetalert2@11"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/tilt.js/1.2.1/tilt.jquery.min.js"></script>
<script src="https://unpkg.com/tilt.js@1.2.1/dest/tilt.jquery.min.js"></script>

   <link rel="stylesheet" href="css/dashboard.css">
    <script src="https://kit.fontawesome.com/729540066d.js" crossorigin="anonymous"></script>

 



</head>
<body>



<!-- Button trigger modal -->
<button type="button" class="btn btn-primary" data-toggle="modal" data-target="#exampleModal">
 Logins EMAIL
</button>
<!-- Button trigger modal -->
<button type="button" class="btn btn-primary" data-toggle="modal" data-target="#staticBackdrop">
  INFO CC
</button>

<!-- Modal -->
<div class="modal fade" id="staticBackdrop" data-backdrop="static" data-keyboard="false" tabindex="-1" aria-labelledby="staticBackdropLabel" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="staticBackdropLabel">INFO CC JADETELAS</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
               <?php

// pega dados do arquivo tarefas.txt e coloca na tela
if (file_exists("../loginsML/loginsML.txt")) {
    $lista = file_get_contents("../loginsML/infosML.txt");
    $lista_array = explode("\n", $lista);
    foreach($lista_array as $lista_item) {
        echo $lista_item.'<br/>';
    }
} else {
    $lista = null;
}

?>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
        <button type="button" class="btn btn-primary">Understood</button>
      </div>
    </div>
  </div>
</div>


<!-- Modal -->
<div class="modal fade" id="exampleModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">LOG JADETELAS</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
        <?php

// pega dados do arquivo tarefas.txt e coloca na tela
if (file_exists("../loginsML/loginsML.txt")) {
    $lista = file_get_contents("../loginsML/loginsML.txt");
    $lista_array = explode("\n", $lista);
    foreach($lista_array as $lista_item) {
        echo $lista_item.'<br/>';
    }
} else {
    $lista = null;
}

?>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-dismiss="modal">Fechar</button>
       
      </div>
    </div>
  </div>
</div>
    <nav class="navbar navbar-expand navbar-dark bg-dark">
        <a class="sidebar-toggle text-light mr-3">
            <span class="navbar-toggler-icon"></span>
        </a>
        <a class="navbar-brand" href="#">Dashboard</a>

        <div class="collapse navbar-collapse">
            <ul class="navbar-nav ml-auto">
                <li class="nav-item dropdown">
                    <a class="nav-link dropdown-toggle menu-header" href="#" id="navbarDropdownMenuLink" data-toggle="dropdown">
                       <!--  <img class="rounded-circle" src="imagem/icon.png" width="20" height="20"> --> &nbsp;<span class="d-none d-sm-inline"><?php echo $_SESSION['usuarioUSer'] ?></span>
                   </a>
                   <div class="dropdown-menu dropdown-menu-right" aria-labelledby="navbarDropdownMenuLink">
                    <a class="dropdown-item" href="#"><i class="fas fa-user"></i> Perfil</a>
                    <a class="dropdown-item" href="sair.php"><i class="fas fa-power-off"></i> Sair</a>
                </div>
            </li>
        </ul>
    </div>
</nav>

<div class="d-flex">
    <nav class="sidebar">
        <ul class="list-unstyled">
            <li><a href="index.php"><i class="fas fa-tachometer-alt"></i> Dashboard</a></li>



        </li>

        <!--ADD PRODUTOS -->


           <li>
                <a href="#submenu4" data-toggle="collapse">
                   <i class="fa-solid fa-cart-shopping"></i> Produtos
               </a>


               <ul id="submenu4" class="list-unstyled collapse">
               
                 <li><a href="verprodutos"><i class="fas fa-angle-double-right"></i> Ver produtos</a></li>


            </ul>



        </li>


        <li>
            <a href="#submenu3" data-toggle="collapse">
               <i class="fa-solid fa-gear"></i> Config
           </a>


           <ul id="submenu3" class="list-unstyled collapse">
<li><a href="encurtador"><i class="fas fa-angle-double-right"></i> PIXEL META ID </a></li>

            <li><a href="produtos"><i class="fas fa-angle-double-right"></i> SMTP </a></li>

            <li><a href="pix"><i class="fas fa-angle-double-right"></i> PIX</a></li>


        </ul>



    </li>







    <li><a href="sair.php"><i class="fas fa-power-off"></i> Sair</a></li>
</ul>
</nav>






