<?php 
include "config/config.php";
include "classcoderphp/pix.php";
include "valor.php";

if(isset($_SESSION['idprodutook'])):
$id = $_SESSION['idprodutook'];
endif;
// echo $_SESSION['idprodutook'];
// echo "<br>";
// echo $_SESSION['title'];
// echo "<br>";
// echo $_SESSION['fotos1'];
// echo "<br>";
// echo $_SESSION['novovalor'];
// echo "<br>";
?>


<section class="carrinho00000101">
    <div class="container-fluid">
        <div class="row">
            <div class="col-md-8">
                <div class="askdlaskdad0101001">
                    <div class="row">
                        <p style="position:relative;top:12px;font-size:18px;font-weight: bold;">Produtos </p>
                    </div>
                </div>


<!-- AQUI COMEÇA O PHP -->

<?php

       
            
                    if(!isset($_SESSION['carrinho'])){
                        $_SESSION['carrinho'] = array();
                    }

                    if(isset($_GET['acao'])){
                        // adicionar carrinho
                        
                        if($_GET['acao'] == 'add'){
                            
                            if(!isset($_SESSION['carrinho'][$id])){
                                $_SESSION['carrinho'][$id]=1;
                                ?>
                                

     <!--                            <script>iziToast.success({
    title: 'Produto',
    message: ' adicionar ao carrinho.',
});
</script> -->



                                <?php
                            }else{
                                 $_SESSION['carrinho'][$id]+=1;
                            }
                        }

                        // REMOVER
                        
                            if($_GET['acao'] == 'del'){
                                    @$id = $_GET['id'];
                                    if(isset($_SESSION['carrinho'][$id])){
                                        unset($_SESSION['carrinho'][$id]);


                                    }
                                }
                        
    if($_GET['acao'] == 'up'){
                                    if(is_array($_POST['prod'])){
                                        foreach($_POST['prod'] as $id => $qtd){
                                            if(!empty($qtd) || $qtd <> 0 ){
                                                $_SESSION['carrinho'][$id] = $qtd;
                                                ?>
       <!--                                                       <script>iziToast.success({
    title: 'Quantidade',
    message: 'Atualizado com sucesso.',
});
</script> -->
<?php
                                            }else{
                                                unset($_SESSION['carrinho'][$id]);
                                            }
                                        }
                                    }
                                }

                    }


            if(count($_SESSION['carrinho']) == 0){
                ?>
               <script>
                window.location.href='index.php';



</script> 

<?php
unset($_SESSION['qtdprodutos']);
            }else{

                foreach($_SESSION['carrinho'] as $id => $qtd){

                                    $aa=[];
                                    $sql=$pdo->prepare("SELECT * FROM coderphp_produtos WHERE id =:id ORDER BY id DESC");
                                    $sql->bindValue(":id", $id);
                                    $sql->execute();

                                    

                                    if($sql->rowCount() > 0){
                                        $aa=$sql->fetchAll(PDO::FETCH_ASSOC);
                                       
                                    }
                                    foreach($aa as $okok){
                                        $_SESSION['title1'] = $okok['title'];
                                         $_SESSION['fotos1'] = $okok['fotos1'];
                                        "<br>";

$altura = $okok['preco'];
$valortotao = $altura = number_format(str_replace(",",".",str_replace(".","",$okok['preco'])), 2, '.', '');

 @$valor_com_desconto = $valortotao - ($valortotao * $pctm * 0.01);
 $valor_com_desconto;
$dois = $valor_com_desconto;

                         $parcelas = 10;
    $valor = $dois; 
    $valorTotal = number_format($valor, 2, '.', '');
    $valor_parcela = $valorTotal / $parcelas;

                                        @$sub = $dois * $qtd;
                                       $_SESSION['qtdprodutos'] = @$qtddsad += $qtd;

                                        "<br>";
                                     $_SESSION['totalpreco'] =   @$total += $sub;

                                      $okokk001 = $sub / $parcelas;

             



                    ?>


                <div class="asdasd222">
                     <div class="row">
                        <div class="col-md-2 col-3">
                            <center><img style="width:80%;" src="<?=$okok['fotos1']?>" alt="" title=""> </center>
                            
                        </div>
                        <div class="col-md-6 col-9">
                                <p class="tittitit" style="font-size:14px;font-weight: bold;"><?=$okok['title']?></p> 
                                <span onclick="window.location.href='?acao=del&id=<?= $id ?>'" style="font-size:13px;margin-left:10px;cursor:pointer;color:rgb(52, 131, 250);">Excluir</span> <span style="font-size:13px;margin-left:10px;cursor:pointer;color:rgb(52, 131, 250);">Salvar</span> 

                            </div>
                            <div class="col-md-2 col-12"><br>
                                <div class="ocultarkkk">
<form method="post" action="?acao=up">

<div style="border-radius:4px;border:solid 1px rgb(194,194,194);width:40% !important;">

                                    <div class="row">




                                     
                                            <div style="cursor:pointer;" class="col-md-4 col-4"><button class="decreaseButton" style="border:none;background:transparent;width:100%;height:auto;"><img style="margin-top:5px;"  src="img/Screenshot_3.png" alt=""></button></div>
                                        <div  class="col-md-4 col-4">

                                             <?= '<input id="counterInput" placeholder="Quantidade" class="quanti qnt_menor_maior" 
                 style="font-weight:bold;border:none !important;;border-radius:4px;outline:none;width:50px;" type="text" name="prod['.$id.']" value='.$qtd.'>' ?>

                                        </div>
                                        <div style="cursor:pointer;"   class="col-md-4 col-4"><button class="increaseButton" style="border:none;background:transparent;width:100%;height:auto;"><img style="margin-left:-10px;"  src="img/Screenshot_2.png" alt=""></button></div>
                                     </div>
</form>
                                    </div>
                 </form>
                                </div>



                                <div class="sdasdaddeixarmobile" style="padding:3px;border-radius:6px;width:100%;height:auto;border:solid 1px rgb(190,190,190);"> <form method="post" action="?acao=up">
                                    <div class="row">




                                        <div style="cursor:pointer;" class="col-md-4 col-4"><button class="decreaseButton" style="border:none;background:transparent;width:100%;height:auto;"><img style="width:100%;" src="img/Screenshot_3.png" alt=""></button></div>
                                        <div  class="col-md-4 col-4">

                                             <?= '<input id="counterInput" placeholder="Quantidade" class="quanti qnt_menor_maior" 
                 style="font-weight:bold;border:none;border-radius:4px;outline:none;width:50px;" type="text" name="prod['.$id.']" value='.$qtd.'>' ?>

                                        </div>
                                        <div style="cursor:pointer;"   class="col-md-4 col-4"><button class="increaseButton" style="border:none;background:transparent;width:100%;height:auto;"><img style="width:100%;" src="img/Screenshot_2.png" alt=""></button></div>
</form>
                                    </div>

                                </div><center><span style="position:relative;top:5px;color:rgb(190,190,190);font-size:12px;">+50 disponíveis</span></center>


              
                            </div>
                               
                            <div class="col-md-2"><br>
                                <center><span style="font-size:18px;">R$ 
<?=  number_format(@$valorTotal,2,",","."); ?></span></center>
                            </div>
                     </div>
                </div>


 <?php 
   }
            }
        } ?> 



                <!-- fim do php -->

                <div style="width:100%; border-bottom:solid 1px rgb(229, 229, 229);">
                    
                </div>
                <div style="background:white;width:100%;height:auto;border-bottom-left-radius:6px;border-bottom-right-radius:6px;">
                    <div style="padding:5px">
                        <p style="position:relative;top:8px;float:left;">Frete</p>
                    <p style="color:rgb(0, 166, 80);position:relative;top:8px;float:right;font-weight:bold;">Grátis</p>
                    <div style="clear:both;"></div>
                    </div>
                </div>
            </div>



            <div class="col-md-4">
            <div class="askdlaskdad0101001">
                    <div class="row">
                        <p style="position:relative;top:12px;font-size:16px;font-weight: 500;">Resumo da compras</p>
                    </div>
                </div>


   <div class="sdasdlaslkd020020202"  style="  width:100%;height:auto;
   padding:10px;
   background:white;
   border-bottom-left-radius:7px;
   border-bottom-right-radius:7px;
   border-bottom:solid 1px rgb(229, 229, 229);
   box-shadow: 0 8px 16px 0 rgba(0, 0, 0, .1);">
                    <div class="row">
                        <div class="col-md-6 col-6">
                            <span style="color:rgb(131,131,131);font-size:12px;float:left;">Produtos (<?=@$qtddsad ?>)</span>
                            
                        </div>
                        <div class="col-md-6 col-6">
                            <span style="color:rgb(131,131,131);font-size:12px;float:right;">R$ 
<?=  number_format(@$sub,2,",",".") ?>
</span>
                        </div>
<br>
                        <div class="col-md-6 col-6">
                            <span style="font-weight:bold;color:rgb(131,131,131);font-size:12px;float:left;">Fretes (2)</span>
                            
                        </div>
                        <div class="col-md-6 col-6">
                            <span style="color:#00a650;font-size:12px;float:right;">Grátis</span>
                        </div>
                    </div>
<BR>

                    <div class="row">
                        <div class="col-md-6 col-6">
                            <span style="color:black;font-size:18px;float:left;">Total</span>
                            
                        </div>
                        <div class="col-md-6 col-6">
                            <span style="color:black;font-size:18px;float:right;">R$ 
<?=  number_format(@$total,2,",","."); ?></span>
                        </div>



                    </div>

<br>

                    
                    <button onclick="window.location.href='checkout'" style="font-weight:500;border:none;padding:12px;color:white;border-radius:4px;width:100%;height:auto;background:rgb(52, 131, 250);">Continuar a compra</button>
                </div>


        
       
                </div>
            </div>
         </div>
    </div>
</section>

<script src="https://code.jquery.com/jquery-3.7.1.js"></script>
<script>
 $(document).ready(function() {
  // Aumentar o valor no input correspondente
  $('.increaseButton').click(function() {
    var input = $(this).closest('.row').find('input');
    var currentValue = parseInt(input.val());  // Pega o valor atual e converte para número
    input.val(currentValue + 1);  // Aumenta o valor no input
  });

  // Diminuir o valor no input correspondente
  $('.decreaseButton').click(function() {
    var input = $(this).closest('.row').find('input');
    var currentValue = parseInt(input.val());  // Pega o valor atual e converte para número
    if (currentValue > 0) {
      input.val(currentValue - 1);  // Diminui o valor no input se for maior que 0
    }
  });
});



</script>