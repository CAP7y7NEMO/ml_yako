<?php

function carrega_pagina()
{

  (isset($_GET['p'])) ? $pagina = $_GET['p'] : $pagina = 'home';

  
  if(isset($_GET['product']))
  {
    include_once('view_coderphp/page_product.php');
  }


  

 if(isset($_GET['cart1']))
  {
    include_once('view_coderphp/page_cart1.php');
  }




  elseif(file_exists('view_coderphp/page_' .$pagina. '.php'))
  {
    require_once('view_coderphp/page_' .$pagina. '.php');
  }


  else
  {
   require_once('view_coderphp/404.php');
 }

}




?>




