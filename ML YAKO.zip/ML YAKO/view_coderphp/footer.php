



<footer class="sdasldklaskdlaskdfoter">
    <div class="container-fluid">
         <div class="row">
              <div class="col-md-4">
                  <center><img src="https://http2.mlstatic.com/storage/homes-korriban/assets/images/ecosystem/payment.svg" alt=""></center><br>
                  <p style="text-align:center;font-size:18px;font-weight:600;color:#4b4b4b;">Escolha como pagar</p>
                  <p style="text-align:center;color:#4b4b4b;font-size:15px;font-weight:400">Com o Mercado Pago, você paga com cartão, boleto ou Pix. Você também pode pagar em até 12x no boleto com o Mercado Crédito.</p>
                  <center><a href="#" style="text-decoration:none;">Como pagar com Mercado Pago</a></center>
              </div>

              <div class="col-md-4">
                  <center><img src="https://http2.mlstatic.com/storage/homes-korriban/assets/images/ecosystem/shipping.svg" alt=""></center><br>
                  <p style="text-align:center;color:#4b4b4b;font-size:18px;font-weight:600;color:#4b4b4b;">Frete grátis a partir de R$ 79
</p>
                  <p style="text-align:center;color:#4b4b4b;font-size:15px;font-weight:400">Ao se cadastrar no Mercado Livre, você tem frete grátis em milhares de produtos.

</p>
                  
              </div>

              <div class="col-md-4">
                   <center><img src="https://http2.mlstatic.com/storage/homes-korriban/assets/images/ecosystem/protected.svg" alt=""></center><br>
                  <p style="text-align:center;color:#4b4b4b;font-size:18px;font-weight:600;color:#4b4b4b;">Segurança, do início ao fim</p>
                  <p style="text-align:center;font-size:15px;font-weight:400">Você não gostou do que comprou? Devolva! No Mercado Livre não há nada que você não possa fazer, porque você está sempre protegido.

</p>
                  <center><a href="#" style="text-decoration:none;">Como te protegemos</a></center>
              </div>
         </div>
    </div>
</footer>






<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-YvpcrYf0tY3lHB60NNkmXc5s9fDVZLESaAA55NDzOxhy9GkcIdslK1eN7N6jIeHz" crossorigin="anonymous"></script>

<script src="https://cdn.jsdelivr.net/npm/swiper/swiper-bundle.min.js"></script>
<script>
        var swiper = new Swiper('.swiper', {
            slidesPerView: 1,
            spaceBetween: 10,
            loop: true, // Loop infinito
            pagination: {
                el: '.swiper-pagination',
                clickable: true,
            },
            navigation: {
                nextEl: '.swiper-button-next',
                prevEl: '.swiper-button-prev',
            },
            // Ative a funcionalidade de toque
            grabCursor: true,

            // Adiciona o autoplay
            autoplay: {
                delay: 3000, // 3000 ms = 3 segundos de intervalo entre os slides
                disableOnInteraction: false, // Continua o autoplay mesmo após a interação do usuário
            }
        });
    </script>
</body>
</html>