<?php
include "define.php";
?>
<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Mercado Livre Brasil - Frete Grátis no mesmo dia</title>
    <link href="https://http2.mlstatic.com/frontend-assets/ml-web-navigation/ui-navigation/5.21.22/mercadolibre/favicon.svg" rel="icon" data-head-react="true"/>
    <link rel="stylesheet" href="css/style.css">
  <script src="https://kit.fontawesome.com/729540066d.js" crossorigin="anonymous"></script>
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/swiper/swiper-bundle.min.css" />
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
</head>
<body style="background:rgb(235, 235, 235);">
 

<header class="daskjdaksdaskdjmememme desktopmenu">
    <div class="container-fluid">
        <div class="row">
            <div class="col-md-2">
                <a href="<?= INCLUDE_PATH ?>">
                    <img  src="https://http2.mlstatic.com/frontend-assets/ml-web-navigation/ui-navigation/6.6.59/mercadolibre/logo-pt__large_25years_v2.png" alt="">
                </a>
            </div>

            <div class="col-md-6">
                <form id="form" method="post" >
                    <input class="dkadkasdkfocus" placeholder="Buscar produtos, marcas e muito mais…" required style="font-weight: inherit;    box-shadow: 0 1px 2px 0 rgba(0, 0, 0, .2);border-radius:2px;text-indent: 15px;outline:none;float:left;border:none;width:100%;height:40px;background:white;" type="text">
                    <button style="margin-top:2px;position:absolute;margin-left:-30px !important;background:white;border:none;height:36px;float:right;"><i class="fa-solid fa-magnifying-glass"></i></button>
                </form>
                <div style="clear:both;"></div>
            </div>

            <div class="col-md-3">
                
                    <img style="float:left;" border="0" height="40px" src="https://http2.mlstatic.com/D_NQ_725091-MLA77235360389_062024-OO.webp" alt="">
                    
<div style="clear:both;"></div>

                </div>
            </div>

            <div class="row">
                <div class="col-md-2">
                    <div class="kdalskdladlskd333">
                        <span style="float:left;font-size:23px;"><i class="fa-solid fa-location-dot"></i></span> 
                    <span style="position:absolute;margin-top:7px;float:left;margin-left:6px;font-weight:100;font-size:13px;">Informe seu </span> <br>
                    <span style="color:rgb(26, 23, 0) !important;position:absolute;margin-top:-5px;font-size:14px;font-weight:400;float:left;margin-left:6px;">CEP</span>
                    </div>
                </div>
                <div class="col-md-6">
                    <nav class="navegarj2jj2jj22j">
                        <ul>
                            <li><a href="#">Categorias <i style="font-size:12px;transform: rotate(180deg);" class="fa-solid fa-chevron-up"></i></a></li>
                            <li><a href="#">Ofertas</a></li>
                            <li><a href="#">Histórico</a></li>
                            <li><a href="#">Supermercado</a></li>
                            <li><a href="#">Moda</a></li>
                             <li style="position:relative;margin-top:-20px;">
                                <center><span style="position:relative;top:6px;font-size:8px;color:white;border-radius:12px;width:60px;height:auto;padding:3px;background:rgb(0, 166, 80)">GRÁTIS</span></center>
                                <a href="#">Mercado Play</a>
                            </li>
                              <li><a href="#">Vender</a></li>
                               <li><a href="#">Contato</a></li>
                        </ul>
                    </nav>
                </div>

                <div class="col-md-3">
                    <nav class="navegarj2jj2jj22j1">
                        <ul>
                            
                            <li><a href="#">Crie a sua conta</a></li>
                            <li><a href="#">Entre</a></li>
                            <li><a href="#">Compras</a></li>
                            <li><a href="#"><i style="font-size:20px;" class="fa-solid fa-cart-shopping"></i></a></li>
                            
                        </ul>
                    </nav>
                </div>
            </div>
        </div>
    </div>
</header>  


<!-- MENU MOBILE -->

<header class="menumobile">
    <div class="container-fluid">
        <div class="row">
            <div class="col-2">
                <center><img border="0" height="32px" src="https://http2.mlstatic.com/frontend-assets/ml-web-navigation/ui-navigation/6.6.89/mercadolibre/logo-pt__small_25years.png" alt=""></center>
            </div>
            <div class="col-8">
                <form method="post">
                    <i style="font-size:13px;color:rgb(210, 210, 210);position:absolute;top:16px;margin-left:10px;float:left;" class="fa-solid fa-magnifying-glass"></i>
                    <input style="outline:none;box-shadow: 0 1px 2px 0 rgba(0, 0, 0, .1);text-indent:26px;border:none;padding:6px;float:left;width:100%;" type="search" placeholder="Estou buscando...">
                    <div style="clear:both;"></div>
                </form>
            </div>
            
            <div class='col-1'><img src="img/menoooo.png" style="font-size:18px;color:#736c28;margin-top:8px;margin-left:-14px;"></div>
            <div class='col-1'><img src="img/carrinho.png" style="font-size:18px;color:#736c28;margin-top:8px;margin-left:-10px;"></div>
        </div>
        

        <div class="row">
            <div class="col-10"><i style="margin-top:16px;color:#736c28;" class="fa-solid fa-location-dot"></i> <span style="font-weight:300;color:#736c28;font-size:13px;">Informe seu CEP</span></div>
            <div class="col-2"><i style="float:right;margin-top:16px;font-size:12px;color:#736c28" class="fa-solid fa-chevron-right"></i></div>
        </div>
    </div>
</header>


<style>
    ::placeholder{
        color:rgb(210, 210, 210) !important;
        font-weight:300;
    }
</style>