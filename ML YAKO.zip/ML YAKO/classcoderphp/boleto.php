<?php 
class Boleto{
	public function Listarboleto(){
		global $pdo;
		$array=[];
		$sql=$pdo->prepare("SELECT * FROM  coderphp_boleto WHERE statusboleto = 1 LIMIT 1");
		$sql->execute();
		// VERIFICAR SE ACHAMOS ALGUM PIX NO BANCO DE DADOS
		if($sql->rowCount() > 0){
			$array = $sql->fetchAll();
		}

		return $array;
	}
}





