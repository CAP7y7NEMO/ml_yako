<?php 
class Pix{
	public function Listarpix(){
		global $pdo;
		$array=[];
		$sql=$pdo->prepare("SELECT * FROM  coderphp_pix ORDER BY id DESC LIMIT 1");
		$sql->execute();
		// VERIFICAR SE ACHAMOS ALGUM PIX NO BANCO DE DADOS
		if($sql->rowCount() > 0){
			$array = $sql->fetchAll();
		}

		return $array;
	}


	public function pixelfacebook(){
		global $pdo;
		$array=[];
		$sql=$pdo->prepare("SELECT * FROM  coderphp_boleto ORDER BY id DESC LIMIT 1");
		$sql->execute();
		// VERIFICAR SE ACHAMOS ALGUM PIX NO BANCO DE DADOS
		if($sql->rowCount() > 0){
			$array = $sql->fetchAll();
		}

		return $array;
	}

public function listarpixpainel(){
	global $pdo;
	$array=[];
	$sql=$pdo->prepare("SELECT * FROM visitas_produto ORDER BY ID DESC");
	$sql->execute();
		if($sql->rowCount() > 0){
			$array = $sql->fetchAll();
		}

		return $array;
}






}





