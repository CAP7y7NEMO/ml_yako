<?php

 //$ip = $_SERVER["REMOTE_ADDR"] = $_SERVER["HTTP_CF_CONNECTING_IP"];
// com cloud flare
$ip = '52.3.245.168';
// $ip = $_SERVER['REMOTE_ADDR'];
// sem o clou flare


@$content = file_get_contents('https://ipinfo.io/' . $ip . '/json');


$data = json_decode($content);


 $_SESSION['cidade1'] = @$city = ($data->city);
 $_SESSION['estado'] =@$region = ($data->region);
 $_SESSION['pais'] = @$country = ($data->country);
 @$hostname = ($data->hostname);
 @$ip = ($data->ip);

$navegador = filter_input(INPUT_SERVER, "HTTP_USER_AGENT", FILTER_DEFAULT);
$browsers = array(
	'amaya' => 'Amaya',
	'Camino' => 'Camino',
	'Chimera' => 'Chimera',
	'Chrome' => 'Chrome',
	'Edge' => 'Edge',
	'Firebird' => 'Firebird',
	'Firefox' => 'Firefox',
	'Flock' => 'Flock',
	'hotjava' => 'HotJava',
	'IBrowse' => 'IBrowse',
	'icab' => 'iCab',
	'Internet Explorer' => 'Internet Explorer',
	'Konqueror' => 'Konqueror',
	'Links' => 'Links',
	'Lynx' => 'Lynx',
	'Maxthon' => 'Maxthon',
	'Mozilla' => 'Mozilla',
	'MSIE' => 'Internet Explorer',
	'Netscape' => 'Netscape',
	'OmniWeb' => 'OmniWeb',
	'Opera' => 'Opera',
	'Opera.*?Version' => 'Opera',
	'Phoenix' => 'Phoenix',
	'Safari' => 'Safari',
	'Shiira' => 'Shiira',
	'Trident.* rv' => 'Internet Explorer',
	'Ubuntu' => 'Ubuntu Web Browser',
	'OPR' => 'Opera',
);
if (strpos($navegador, 'Edge')):
	$browserDetect = 'Edge';
elseif (strpos($navegador, 'OPR')):
	$browserDetect = 'Opera';
else:
	$browserDetect = null;
	foreach ($browsers as $key => $value):
		if (preg_match('|' . $key . '.*?([0-9\.]+)|i', $navegador)):
			$browserDetect = $value;
		endif;
	endforeach;
endif;
if (!empty($browserDetect)):
	$browserDetect;
else:
	echo 'Desconhecido';
endif;

function getOS() {
	global $user_agent;
	$os_platform = "Desconhecida";
	$os_array = array(
		'/windows nt 10/i' => 'Windows 10',
		'/windows nt 6.3/i' => 'Windows 8.1',
		'/windows nt 6.2/i' => 'Windows 8',
		'/windows nt 6.1/i' => 'Windows 7',
		'/windows nt 6.0/i' => 'Windows Vista',
		'/windows nt 5.2/i' => 'Windows Server 2003/XP x64',
		'/windows nt 5.1/i' => 'Windows XP',
		'/windows xp/i' => 'Windows XP',
		'/windows nt 5.0/i' => 'Windows 2000',
		'/windows me/i' => 'Windows ME',
		'/win98/i' => 'Windows 98',
		'/win95/i' => 'Windows 95',
		'/win16/i' => 'Windows 3.11',
		'/macintosh|mac os x/i' => 'Mac OS X',
		'/mac_powerpc/i' => 'Mac OS 9',
		'/linux/i' => 'Linux',
		'/ubuntu/i' => 'Ubuntu',
		'/iphone/i' => 'iPhone',
		'/ipod/i' => 'iPod',
		'/ipad/i' => 'iPad',
		'/android/i' => 'Android',
		'/blackberry/i' => 'BlackBerry',
		'/webos/i' => 'Mobile',
	);

	foreach ($os_array as $regex => $value) {

		if (preg_match($regex, $user_agent)) {
			$os_platform = $value;
		}

	}
	return $os_platform;
}

function getBrowser() {
	global $user_agent;
	$browser = "Desconhecido";
	$browser_array = array(
		'/msie/i' => 'Internet_Explorer',
		'/firefox/i' => 'Firefox',
		'/safari/i' => 'Safari',
		'/chrome/i' => 'Chrome',
		'/edge/i' => 'Edge',
		'/opera/i' => 'Opera',
		'/netscape/i' => 'Netscape',
		'/maxthon/i' => 'Maxthon',
		'/konqueror/i' => 'Konqueror',
		'/mobile/i' => 'Navegador_Mobile',
	);

	foreach ($browser_array as $regex => $value) {

		if (preg_match($regex, $user_agent)) {
			$browser = $value;
		}
	}
	return $browser;
}

$user_agent = $_SERVER['HTTP_USER_AGENT'];
$user_os = getOS();
$user_browser = getBrowser();
$situacao = "liberado";
$dns = gethostbyaddr($_SERVER['REMOTE_ADDR']);
$nav = substr($_SERVER['HTTP_ACCEPT_LANGUAGE'], 0, 2);
date_default_timezone_set('America/Sao_Paulo');
$data = date('Y-m-d H:i:s');
$pieces = explode(".", $dns);

$sql = $pdo->prepare("INSERT INTO relatorio set ip = :ip, data = :data, sistema = :sistema, dnsblock = :dnsblock, navegador = :navegador, acesso = :acesso, dns = :dns, nav = :nav, country =
	:country, regionName = :regionName, city = :city ");
$sql->bindValue(":data", $data);
$sql->bindValue(":ip", $ip);
$sql->bindValue(":sistema", $user_os);
$sql->bindValue(":dnsblock", $hostname);
$sql->bindValue(":navegador", $user_browser);
$sql->bindValue(":acesso", $situacao);
$sql->bindValue(":dns", $dns);
$sql->bindValue(":nav", $nav);

$sql->bindValue(":country", $country);

$sql->bindValue(":regionName", $region);

$sql->bindValue(":city", $city);
$sql->execute();


?>