<?php

global $pdo;

$pix = new Pix();
$dadospix = $pix->Listarpix();

foreach($dadospix as $coderphppix):
$coderphppix['chavepix'];
$coderphppix['porcentagem'];
endforeach;


// PORCENTAGEM 
$pctm = $coderphppix['porcentagem'];
$chave_pix =  $coderphppix['chavepix'];
$beneficiario_pix = "MERCADOLIVRE";
$cidade_pix = "MERCADOLIVRE";
$descricao = "MERCADOLIVRE";
$identificador="***";
@$valor_pix =  $dois;


?>