<?php 
session_start();

if($_POST['pg'] === 'pix'):

echo "<script>
window.location.href='pix.php';
</script>";

endif;	
if($_POST['pg'] === 'card'):

echo "<script>
window.location.href='cartbuying.php';
</script>";

endif;

?>